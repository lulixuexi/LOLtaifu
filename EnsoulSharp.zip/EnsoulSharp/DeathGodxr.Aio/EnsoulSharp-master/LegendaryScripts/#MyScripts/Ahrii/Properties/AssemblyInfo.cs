﻿using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("EnsoulSharp.Ahri")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("EnsoulSharp.Ahri")]
[assembly: AssemblyCopyright("Copyright ©  2019")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("9d6939ab-ae1d-4bb1-b0dd-7e1f82f2bc57")]
[assembly: AssemblyVersion("1.0.0.3")]
[assembly: AssemblyFileVersion("1.0.0.3")]
