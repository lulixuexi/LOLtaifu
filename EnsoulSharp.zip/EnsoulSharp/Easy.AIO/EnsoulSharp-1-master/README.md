#### Easy_Mid :
  - Brand
  - Diana


#### Easy_Sup :
  - Alistar
  - Blitz
  - Lux
  - Morgana
  - Pyke
  - Soraka
  - Thresh
