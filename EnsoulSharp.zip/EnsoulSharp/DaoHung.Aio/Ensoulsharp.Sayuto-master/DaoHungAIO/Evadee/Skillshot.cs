﻿using System;
namespace DH.Yasuo.Evadee
{
    public class Skillshot
    {
        public Skillshot()
        {
        }
    }
}
