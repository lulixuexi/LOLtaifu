﻿using System;
namespace DaoHungAIO.Helpers
{
    public class Menu
    {
        public Menu()
        {
        }
    }
}
