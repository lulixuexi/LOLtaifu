﻿using System;
namespace KDA_Akali
{
    public class Switch
    {
        public Switch()
        {
        }
    }
}
