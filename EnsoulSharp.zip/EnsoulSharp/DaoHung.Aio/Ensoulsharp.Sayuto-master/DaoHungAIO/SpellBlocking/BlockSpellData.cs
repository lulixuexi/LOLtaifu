﻿namespace SpellBlocking
{
    #region

    using EnsoulSharp;

    #endregion

    internal class BlockSpellData
    {
        public SpellSlot SpellSlot { get; set; }
        public string ChampionName { get; set; }
    }
}
