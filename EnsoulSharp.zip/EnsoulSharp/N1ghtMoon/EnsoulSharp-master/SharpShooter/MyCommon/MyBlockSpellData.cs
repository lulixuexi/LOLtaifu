﻿namespace SharpShooter.MyCommon
{
    #region

    using EnsoulSharp;

    #endregion

    public class MyBlockSpellData
    {
        public SpellSlot SpellSlot { get; set; }
        public string CharacterName { get; set; }
    }
}
