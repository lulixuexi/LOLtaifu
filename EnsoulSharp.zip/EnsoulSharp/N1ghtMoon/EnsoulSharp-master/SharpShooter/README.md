﻿#SharpShooter

This is basic on my old Aimkek Project

i dont have test, maybe it have some bugs

本人QQ群: 598027398

--------------------------------------------------

Support List
--------------------------------------------------
Ashe, Caitlyn, Corki, Draven, Ezreal, Graves, Jhin, Jinx, Kalista, KogMaw, MissFortune,

Lucian, Quinn, Sivir, Tristana, TwistedFate, Twitch, Urgot, Varus, Vayne, Xayah


Ashe
--------------------------------------------------

Basic Logic (QWER)

Combo R Logic (Solo and Team Fight)

Full Farm Logic

Mana Manager (Harass/LaneClear/JungleClear Mode)

KillSteal Logic

Semi R Logic

Spell Range Circle


Caitlyn
--------------------------------------------------

Basic Logic (QWER)

Combo W Use Logic (Smart, Custom Stack)

Combo R Use Logic (Safe Check, Min Cast Range DIY)

Full Farm Logic

Mana Manager (Harass/LaneClear/JungleClear Mode)

KillSteal Logic

Auto Q/W Logic (CC/TP)

Semi R/EQ Logic

Spell Range Circle

Corki
--------------------------------------------------

Basic Logic (QWER)

Combo R Use Logic (Custom Stack and target HP Check)

Smart Collsion Minion to Hit target

Full Farm Logic (Harass/LaneClear/JungleClear Mode)

Mana Manager (Harass/LaneClear/JungleClear Mode)

KillSteal Logic

Semi R Logic

Spell Range Circle

Draven
--------------------------------------------------

Basic Logic (QWER)

Two Combo R Logic (Solo KS and Team Fight)

Full Farm Logic (Harass/LaneClear/JungleClear Mode)

Mana Manager (Harass/LaneClear/JungleClear Mode)

KillSteal Logic

High Custom Axe Catch Logic (DIY)

Auto W (slowing)

Global R Range Settings

Semi R Logic

Draw Axe Position and Draw Axe Catch Range

Spell Range Circle

Ezreal
--------------------------------------------------

Basic Logic (QWER)

Combo E Logic (KS)

Combo R AOE Logic

Full Farm Logic (Harass/LaneClear/JungleClear Mode)

Mana Manager (Harass/LaneClear/JungleClear Mode)

KillSteal Logic

R Custom and Semi R Logic

Spell Range Circle

Graves
--------------------------------------------------

Basic Logic (QWER)

Fast E Reset Attack (Combo/JungleClear Mode)

Safe E Check

Combo R AOE Logic

Full Farm Logic (Harass/LaneClear/JungleClear Mode)

Mana Manager (Harass/LaneClear/JungleClear Mode)

KillSteal Logic

Spell Range Circle

Kalista
--------------------------------------------------

Basic Logic (QER)

Combo/Harass E Slow Logic

Full Farm Logic (Harass/LaneClear/JungleClear Mode)

Mana Manager (Harass/LaneClear/JungleClear Mode)

KillSteal Logic

Steal Mob Logic

Balista Logic

Auto R Save Ally Logic

Forcus Attack Passive Logic

Spell Range Circle

KogMaw
--------------------------------------------------

Basic Logic (QWER)

Combo R Custom Logic (Max Buff Count, target Health check)

Full Farm Logic (Harass/LaneClear/JungleClear Mode)

Mana Manager (Harass/LaneClear/JungleClear Mode)

KillSteal Logic

Spell Range Circle

Lucian
--------------------------------------------------

Basic Logic (QWER)

Combo/Harass Q Extend Logic

Faster Combo W Reset Auto Attack Logic

Five Combo E Custom Option

Full Farm Logic (Harass/LaneClear/JungleClear Mode)

Mana Manager (Harass/LaneClear/JungleClear Mode)

KillSteal Logic

Semi R Logic

Spell Range Circle

MissFortune
--------------------------------------------------

Basic Logic (QWE)

Combo/Harass Q Extend Logic

Full Farm Logic (Harass/LaneClear/JungleClear Mode)

Mana Manager (Harass/LaneClear/JungleClear Mode)

KillSteal Logic

Semi R Logic

Spell Range Circle

Jhin
--------------------------------------------------

Basic Logic (QWER)

Combo/Harass Q On Minion Logic

Combo W After Attack/ Only Use on passive target

Smart LaneClear Logic

Full Farm Logic (Harass/LaneClear/JungleClear Mode)

Mana Manager (Harass/LaneClear/JungleClear Mode)

KillSteal Logic

Auto W/E CC Logic

R Custom and Semi R Logic

Spell Range Circle

Jinx
--------------------------------------------------

Basic Logic (QWER)

Two Combo R Logic (Solo/Team)

Full Farm Logic (Harass/LaneClear/JungleClear Mode)

Mana Manager (Harass/LaneClear/JungleClear Mode)

KillSteal Logic

Auto W/E CC Logic

Auto W/E CC Logic

R Custom and Semi R Logic

Spell Range Circle

Quinn
--------------------------------------------------

Basic Logic (QWE)

Full Farm Logic (Harass/LaneClear/JungleClear Mode)

Mana Manager (Harass/LaneClear/JungleClear Mode)

KillSteal Logic

Forcus Attack Passive Target

Auto R Logic (In Fountain)

Spell Range Circle

Sivir
--------------------------------------------------

Basic Logic (QWER)

Full Farm Logic (Harass/LaneClear/JungleClear Mode)

Mana Manager (Harass/LaneClear/JungleClear Mode)

KillSteal Logic

Auto Q Logic

Auto R Logic

Special E Block Spell Logic

Spell Range Circle

Twitch
--------------------------------------------------

Basic Logic (QWER)

Custom Combo Q Logic

Combo R Logic (KS and Team Fight)

Custom Combo/Harass E Logic

Full Farm Logic (Harass/LaneClear/JungleClear Mode)

Mana Manager (Harass/LaneClear/JungleClear Mode)

KillSteal Logic

Spell Range Circle

Tristana
--------------------------------------------------

Basic Logic (QER)

Combo QE Custom Logic

Combo R SaveMySelf Logic

Cast E To Minion To Harass Enemy Logic

Full Farm Logic (Harass/LaneClear/JungleClear Mode)

Mana Manager (Harass/LaneClear/JungleClear Mode)

KillSteal Logic

Semi E Logic

Forcus Attack Passive Logic

Spell Range Circle

TwistedFate
--------------------------------------------------

Basic Logic (QW)

Combo Save Mana Cast W Logic

Combo Smart Card KS Logic (Custom)

Auto Disable Attack When Selecting Card

Full Farm Logic (Harass/LaneClear/JungleClear Mode)

Mana Manager (Harass/LaneClear/JungleClear Mode)

KillSteal Logic

Select Card Logic(Key)

Semi Q Logic

Auto Q Logic

Auto Gold Card In Ult

Spell Range Circle

Varus
--------------------------------------------------

Basic Logic (QWER)

Combo R Logic (KS or AOE)

Combo Custom Passive Spell Using (Q/E)

Combo Fast Q Logic

Full Farm Logic (Harass/LaneClear/JungleClear Mode)

Mana Manager (Harass/LaneClear/JungleClear Mode)

KillSteal Logic

Semi R Logic

Spell Range Circle

Vayne
--------------------------------------------------

Basic Logic(QER)

Combo Q Dash Logic

Combo Q Reset Attack Logic

Combo R Logic (Check Enemies Count and Check Player Health)

Harass Logic

Full Farm Logic (Harass/LaneClear/JungleClear Mode)

Mana Manager (Harass/LaneClear/JungleClear Mode)

KillSteal Logic

Q Check Safe Logic

Auto R Logic

Forcus Attack Passive Target

Stealth Logic (High Custom)

Spell Range Circle

Xayah
--------------------------------------------------

Basic Logic(QWE)

Two Combo E Logic (imprision and KS)

R Block Spell Logic

Full Farm Logic (Harass/LaneClear/JungleClear Mode)

Mana Manager (Harass/LaneClear/JungleClear Mode)

KillSteal Logic

Spell Range Circle
