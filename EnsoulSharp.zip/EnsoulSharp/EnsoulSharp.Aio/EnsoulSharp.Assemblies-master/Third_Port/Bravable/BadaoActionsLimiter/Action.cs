﻿using EnsoulSharp;

namespace BadaoActionsLimiter
{
    public class Action
    {
        public SpellSlot Slot;
        public int Tick;
    }
}