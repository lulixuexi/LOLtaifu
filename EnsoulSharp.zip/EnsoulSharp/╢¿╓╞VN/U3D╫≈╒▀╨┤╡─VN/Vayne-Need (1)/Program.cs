﻿using EnsoulSharp.SDK;
namespace VayneNeed
{
    public class Program
    {
        public static void Main(string[] args)
        {
            GameEvent.OnGameLoad += delegate
            {
                Vayne.OnLoad();
            };
        }
    }
}
