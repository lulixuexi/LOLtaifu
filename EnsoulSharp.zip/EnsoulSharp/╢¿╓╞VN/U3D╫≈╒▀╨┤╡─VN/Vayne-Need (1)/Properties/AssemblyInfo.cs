﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Vayne-Need")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Need")]
[assembly: AssemblyProduct("Vayne-Need")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2019")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]


[assembly: Guid("8abab33e-534f-445f-8f9c-f0bbfbbf1abf")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
