﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnsoulSharp;
using EnsoulSharp.SDK;
using EnsoulSharp.SDK.MenuUI;
using EnsoulSharp.SDK.Prediction;
using EnsoulSharp.SDK.Utility;
using SharpDX;

namespace xDreamms_Ahri
{
    class Program
    {
        //Save
        private static Menu Config;

        private static Spell Q, W, E, R;
        private static AIHeroClient Player;
        const float _spellQSpeed = 2600;
        const float _spellQSpeedMin = 400;
        const float _spellQFarmSpeed = 1600;
        const float _spellQAcceleration = -3200;
        private static SpellSlot Ignite;
        static void Main(string[] args)
        {
            GameEvent.OnGameLoad += GameEventOnOnGameLoad;
        }

        private static void GameEventOnOnGameLoad()
        {
            Player = ObjectManager.Player;
            if (Player.CharacterName != "Ahri") return;
            CreateSpells();
            CreateMenu();
            CreateEvents();
        }

        private static void CreateEvents()
        {
            Gapcloser.OnGapcloser += GapcloserOnOnGapcloser;
            Interrupter.OnInterrupterSpell += InterrupterOnOnInterrupterSpell;
            Drawing.OnEndScene += DrawingOnOnEndScene;
            Game.OnTick += GameOnOnUpdate;
            Chat.Print("<font color=\"#008aff\"> xDreamms Ahri </font> ver 1.0 by <font color=\"#FF0000\"> xDreamms</font> - <font color=\"#00BFFF\">Loaded</font>");

        }

        private static void DrawingOnOnEndScene(EventArgs args)
        {
            if (!ObjectManager.Player.IsDead)
            {
                var drawQ = DrawQ;
                var drawW = DrawW;
                var drawE = DrawE;

                if (drawQ)
                    Render.Circle.DrawCircle(ObjectManager.Player.Position, Q.Range, System.Drawing.Color.Red);

                if (drawE)
                    Render.Circle.DrawCircle(ObjectManager.Player.Position, E.Range, System.Drawing.Color.Brown);

                if (drawW)
                    Render.Circle.DrawCircle(ObjectManager.Player.Position, W.Range, System.Drawing.Color.Blue);
            }
        }

        private static void GameOnOnUpdate(EventArgs args)
        {
            switch (Orbwalker.ActiveMode)
            {
                case OrbwalkerMode.Combo:
                    Combo();
                    break;
                case OrbwalkerMode.Harass:
                    Harass();
                    break;
                case OrbwalkerMode.LaneClear:
                    LaneClear();
                    break;
                default:
                    break;
            }
            KillSteal();
        }

        private static void KillSteal()
        {
            if (KillStealIgnite && Ignite.IsReady())
            {
                var target = TargetSelector.GetTarget(600, DamageType.True);
                if (target != null && CastIgnite(target))
                {
                    return;
                }
            }
        }

        private static void LaneClear()
        {
            Q.Speed = _spellQFarmSpeed;
            var minions = GameObjects.EnemyMinions.Where(x => x.IsValidTarget(Q.Range) && !x.IsAlly).ToList();
            bool jungleMobs = minions.Any(x => x.Team == GameObjectTeam.Neutral);

            if ((FarmQ && ObjectManager.Player.ManaPercent >= FarmPercent && ObjectManager.Player.Level >= FarmStartAtLevel) || jungleMobs)
            {
                var farmLocation = Q.GetLineFarmLocation(minions);

                if (farmLocation.Position.IsValid())
                    if (farmLocation.MinionsHit >= 2 || jungleMobs)
                        CastQ(farmLocation.Position);
            }
            minions = GameObjects.EnemyMinions.Where(x => x.IsValidTarget(W.Range) && !x.IsAlly).ToList();


            if (minions.Count() > 0)
            {
                jungleMobs = minions.Any(x => x.Team == GameObjectTeam.Neutral);

                if ((FarmW && ObjectManager.Player.ManaPercent >= FarmPercent && ObjectManager.Player.Level >= FarmStartAtLevel) || jungleMobs)
                    CastW(true);
            }
        }

        static void Harass()
        {
            if (HarassE && ObjectManager.Player.ManaPercent >= HarassPercent)
                CastE();

            if (HarassQ && ObjectManager.Player.ManaPercent >= HarassPercent)
                CastQ();
        }
        static void CastQ()
        {
            if (!Q.IsReady())
            {
                return;
            }

            var target = TargetSelector.GetTarget(Q.Range, DamageType.Magical);

            if (target != null)
            {
                var predictedPos = SpellPrediction.GetPrediction(target, Q.Delay * 1.5f); //correct pos currently not possible with spell acceleration
                if (predictedPos.Hitchance >= HitChance.VeryHigh)
                {
                    Q.Speed = GetDynamicQSpeed(ObjectManager.Player.Distance(predictedPos.UnitPosition));
                    if (Q.Speed > 0f)
                    {
                        Q.Cast(target);
                    }
                }
            }
        }
        static bool CastE()
        {
            if (!E.IsReady())
            {
                return false;
            }

            var target = TargetSelector.GetTarget(E.Range, DamageType.Magical);

            if (target != null)
            {
                return E.CastIfHitchanceEquals(target, HitChance.VeryHigh);
            }

            return false;
        }
        static void CastW(bool ignoreTargetCheck = false)
        {
            if (!W.IsReady())
            {
                return;
            }

            var target = TargetSelector.GetTarget(W.Range, DamageType.Magical);

            if (target != null || ignoreTargetCheck)
            {
                W.CastOnUnit(ObjectManager.Player);
            }
        }
        static float GetDynamicQSpeed(float distance)
        {
            var a = 0.5f * _spellQAcceleration;
            var b = _spellQSpeed;
            var c = -distance;

            if (b * b - 4 * a * c <= 0f)
            {
                return 0;
            }

            var t = (float)(-b + Math.Sqrt(b * b - 4 * a * c)) / (2 * a);
            return distance / t;
        }
        static void CastQ(Vector2 pos)
        {
            if (!Q.IsReady())
                return;

            Q.Cast(pos);
        }

        static void Combo()
        {
            if (ComboE)
            {
                if (CastE())
                {
                    return;
                }
            }

            if (ComboQ)
            {
                CastQ();
            }


            if (ComboW)
            {
                CastW();
            }


            if (ComboR && R.IsReady())
            {
                if (OkToUlt())
                {
                    R.Cast(Game.CursorPosCenter);
                }
            }
        }
        static bool OkToUlt()
        {
            if (GameObjects.EnemyHeroes.Any(x => x.Distance(ObjectManager.Player) < 500)) //any enemies around me?
                return true;

            Vector3 mousePos = Game.CursorPosCenter;

            var enemiesNearMouse = GameObjects.EnemyHeroes.Where(x => x.Distance(ObjectManager.Player) < R.Range && x.Distance(mousePos) < 650);

            if (enemiesNearMouse.Count() > 0)
            {
                if (IsRActive()) //R already active
                    return true;

                bool enoughMana = ObjectManager.Player.Mana > ObjectManager.Player.Spellbook.GetSpell(SpellSlot.Q).ManaCost + ObjectManager.Player.Spellbook.GetSpell(SpellSlot.E).ManaCost + ObjectManager.Player.Spellbook.GetSpell(SpellSlot.R).ManaCost;

                if (ComboROnlyUserInitiate || !(Q.IsReady() && E.IsReady()) || !enoughMana) //dont initiate if user doesnt want to, also dont initiate if Q and E isnt ready or not enough mana for QER combo
                    return false;

                var friendsNearMouse = GameObjects.AllyHeroes.Where(x => x.IsMe || x.Distance(mousePos) < 650); //me and friends near mouse (already in fight)

                if (enemiesNearMouse.Count() == 1) //x vs 1 enemy
                {
                    AIHeroClient enemy = enemiesNearMouse.FirstOrDefault();

                    bool underTower = enemy.IsUnderEnemyTurret();

                    return GetComboDamage(enemy) / enemy.Health >= (underTower ? 1.25f : 1); //if enemy under tower, only initiate if combo damage is >125% of enemy health
                }
                else //fight if enemies low health or 2 friends vs 3 enemies and 3 friends vs 3 enemies, but not 2vs4
                {
                    int lowHealthEnemies = enemiesNearMouse.Count(x => x.Health / x.MaxHealth <= 0.1); //dont count low health enemies

                    float totalEnemyHealth = enemiesNearMouse.Sum(x => x.Health);

                    return friendsNearMouse.Count() - (enemiesNearMouse.Count() - lowHealthEnemies) >= -1 || ObjectManager.Player.Health / totalEnemyHealth >= 0.8;
                }
            }

            return false;
        }
        static float GetComboDamage(AIBaseClient target)
        {
            double comboDamage = 0;
            if (Q.IsReady())
                comboDamage += Player.GetSpellDamage(target, Q.Slot);
            if (W.IsReady())
                comboDamage += Player.GetSpellDamage(target, W.Slot);
            if (E.IsReady())
                comboDamage += Player.GetSpellDamage(target, E.Slot);
            if (R.IsReady())
                comboDamage += Player.GetSpellDamage(target, R.Slot);


            return (float)(comboDamage + ObjectManager.Player.GetAutoAttackDamage(target));
        }

        static bool IsRActive()
        {
            return ObjectManager.Player.HasBuff("AhriTumble");
        }
        static int GetRStacks()
        {
            return ObjectManager.Player.GetBuffCount("AhriTumble");
        }


        private static void InterrupterOnOnInterrupterSpell(AIHeroClient sender, Interrupter.InterruptSpellArgs args)
        {
            if (!AutoEI) return;

            if (ObjectManager.Player.Distance(sender) < E.Range * E.Range && sender.IsEnemy)
            {
                E.Cast(sender);
            }
        }

        private static void GapcloserOnOnGapcloser(AIHeroClient gapcloser, Gapcloser.GapcloserArgs args)
        {
            if (!AutoE) return;
            if (ObjectManager.Player.Distance(gapcloser) < E.Range * E.Range && gapcloser.IsEnemy)
            {
                E.Cast(gapcloser);
            }
        }

        private static void CreateMenu()
        {
            Config = new Menu("xDreammsAhri", "xDreamms Ahri", true);
            //Combo Menu
            var comboMenu = new Menu("Combo", "Combo");
            Helper.AddMenuBool(comboMenu, "ComboQ", "Use Q", true);
            Helper.AddMenuBool(comboMenu, "ComboW", "Use W", true);
            Helper.AddMenuBool(comboMenu, "ComboE", "Use E", true);
            Helper.AddMenuBool(comboMenu, "ComboR", "Use R", true);
            Helper.AddMenuBool(comboMenu, "ComboROnlyUserInitiate", "Use R only if user initiated", false);
            Config.Add(comboMenu);

            //Harass Menu
            var harassMenu = new Menu("Harass", "Harass");
            Helper.AddMenuBool(harassMenu, "HarassQ", "Use Q", true);
            Helper.AddMenuBool(harassMenu, "HarassE", "Use E", true);
            Helper.AddMenuSlider(harassMenu, "HarassPercent", "Skills until Mana %", 20, 0, 100);
            Config.Add(harassMenu);

            //Farm Menu
            var farmMenu = new Menu("LaneClear", "Lane Clear");
            Helper.AddMenuBool(farmMenu, "FarmQ", "Use Q", true);
            Helper.AddMenuBool(farmMenu, "FarmW", "Use W", false);
            Helper.AddMenuSlider(farmMenu, "FarmPercent", "Skills until Mana %", 20, 0, 100);
            Helper.AddMenuSlider(farmMenu, "FarmStartAtLevel", "Only AA until Level", 8, 1, 18);
            Config.Add(farmMenu);

            var drawMenu = new Menu("Drawings", "Drawings");
            Helper.AddMenuBool(drawMenu, "DrawQ", "Draw Q range", true);
            Helper.AddMenuBool(drawMenu, "DrawW", "Draw W range", true);
            Helper.AddMenuBool(drawMenu, "DrawE", "Draw E range", true);
            Helper.AddMenuBool(drawMenu, "DamageAfterCombo", "Draw Combo Damage", true);
            Config.Add(drawMenu);

            var miscMenu = new Menu("Misc", "Misc");
            Helper.AddMenuBool(miscMenu, "AutoE", "Auto E on gapclosing targets", true);
            Helper.AddMenuBool(miscMenu, "AutoEI", "Auto E to interrupt", true);
            Helper.AddMenuBool(miscMenu, "KillStealIgnite", "KillSteal with Ignite", true);
            Config.Add(miscMenu);

            Config.Attach();
        }
        public static bool CastIgnite(AIHeroClient target)
        {
            return Ignite.IsReady() && target.IsValidTarget(600)
                   && target.Health + 5 < Player.GetSummonerSpellDamage(target, SummonerSpell.Ignite)
                   && Player.Spellbook.CastSpell(Ignite, target);
        }
        private static void CreateSpells()
        {
            Q = new Spell(SpellSlot.Q, 880);
            W = new Spell(SpellSlot.W, 700);
            E = new Spell(SpellSlot.E, 975);
            R = new Spell(SpellSlot.R, 1000 - 100);
            Ignite = Player.GetSpellSlot("summonerdot");

            Q.SetSkillshot(0.25f, 50, 1600f, false, false, SkillshotType.Line);
            W.SetSkillshot(0.70f, W.Range, float.MaxValue, false, false, SkillshotType.Circle);
            E.SetSkillshot(0.25f, 60, 1550f, true, false, SkillshotType.Line);
        }

        public static bool ComboQ { get { return Helper.GetMenuBoolValue(Config, "Combo", "ComboQ"); } }
        public static bool KillStealIgnite { get { return Helper.GetMenuBoolValue(Config, "Misc", "KillStealIgnite"); } }

        public static bool ComboW { get { return Helper.GetMenuBoolValue(Config, "Combo", "ComboW"); } }
        public static bool ComboE { get { return Helper.GetMenuBoolValue(Config, "Combo", "ComboE"); } }
        public static bool ComboR { get { return Helper.GetMenuBoolValue(Config, "Combo", "ComboR"); } }
        public static bool ComboROnlyUserInitiate { get { return Helper.GetMenuBoolValue(Config, "Combo", "ComboROnlyUserInitiate"); } }
        public static bool HarassQ { get { return Helper.GetMenuBoolValue(Config, "Harass", "HarassQ"); } }
        public static bool HarassE { get { return Helper.GetMenuBoolValue(Config, "Harass", "HarassE"); } }
        public static int HarassPercent { get { return Helper.GetMenuSliderValue(Config, "Harass", "HarassPercent"); } }
        public static bool FarmQ { get { return Helper.GetMenuBoolValue(Config, "LaneClear", "FarmQ"); } }
        public static bool FarmW { get { return Helper.GetMenuBoolValue(Config, "LaneClear", "FarmW"); } }
        public static int FarmPercent { get { return Helper.GetMenuSliderValue(Config, "LaneClear", "FarmPercent"); } }

        public static int FarmStartAtLevel { get { return Helper.GetMenuSliderValue(Config, "LaneClear", "FarmStartAtLevel"); } }

        public static bool DrawQ { get { return Helper.GetMenuBoolValue(Config, "Drawings", "DrawQ"); } }
        public static bool DrawW { get { return Helper.GetMenuBoolValue(Config, "Drawings", "DrawW"); } }
        public static bool DrawE { get { return Helper.GetMenuBoolValue(Config, "Drawings", "DrawE"); } }
        public static bool DamageAfterCombo { get { return Helper.GetMenuBoolValue(Config, "Drawings", "DamageAfterCombo"); } }
        public static bool AutoE { get { return Helper.GetMenuBoolValue(Config, "Misc", "AutoE"); } }
        public static bool AutoEI { get { return Helper.GetMenuBoolValue(Config, "Misc", "AutoEI"); } }
    }
}
