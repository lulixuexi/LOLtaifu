﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindWalker_Yasuo
{
    public class WBlockSpellDatabase
    {
        public static List<String> DangerousList = new List<string>()
        {
            "JavelinToss",
            "AhriSeduce",
            "BandageToss",
            "FlashFrost",
            "Disintegrate",
            "Volley",
            "EnchantedCrystalArrow",
            "BardQ",
            "RocketGrab",
            "BraumQ",
            "BraumRWrapper",
            "CaitlynPiltoverPeacemaker",
            "CaitlynEntrapment",
            "CaitlynAceintheHole",
            "PhosphorusBomb",
            "DianaArc",
            "InfectedCleaverMissileCast",
            "DravenDoubleShot",
            "DravenRCast",
            "EkkoQ",
            "EliseHumanE",
            "EzrealTrueshotBarrage",
            "FioraW",
            "FizzMarinerDoom",
            "GalioRighteousGust",
            "GnarQ",
            "GnarBigQ",
            "GragasR",
            "GravesQLineSpell",
            "GravesChargeShot",
            "HeimerdingerW",
            "HeimerdingerE",
            "IllaoiE",
            "IreliaTranscendentBlades",
            "HowlingGale",
            "JayceShockBlast",
            "JhinW",
            "JhinRShot",
            "JinxW",
            "SkillshotMissileLine",
            "KalistaMysticShot",
            "KarmaQMantra",
            "KennenShurikenHurlMissile1",
            "KhazixW",
            "LeblancSoulShackle",
            "BlindMonkQOne",
            "LissandraQ",
            "LuluQ",
            "LuxLightBinding",
            "DarkBindingMissile",
            "NamiR",
            "NautilusAnchorDrag",
            "OlafAxeThrowCast",
            "QuinnQ",
            "PoppyRSpell",
            "RengarE",
            "RumbleGrenade",
            "SejuaniGlacialPrisonStart",
            "SorakaE",
            "SonaR",
            "TahmKenchQ",
            "ThreshQ",
            "VarusQ",
            "VarusR",
            "ViktorDeathRay",
            "XerathMageSpear",
            "ZedQ",
            "ZileanQ",
            "ZyraGraspingRoots",
            "ZyraBrambleZone"


        };
    }
}
