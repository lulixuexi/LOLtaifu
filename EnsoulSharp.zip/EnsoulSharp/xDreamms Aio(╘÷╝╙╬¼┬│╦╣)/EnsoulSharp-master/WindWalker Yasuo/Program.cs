﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EnsoulSharp;
using EnsoulSharp.SDK;
using EnsoulSharp.SDK.MenuUI.Values;
using EnsoulSharp.SDK.Prediction;
using EnsoulSharp.SDK.Utility;
using SharpDX;
using System.Drawing;
using Menu = EnsoulSharp.SDK.MenuUI.Menu;

namespace WindWalker_Yasuo
{
    class Program
    {

        private static Spell Q, Q2, W, E, R;
        private const int QRange = 550, Q2Range = 1150, QCirWidth = 275, QCirWidthMin = 250, RWidth = 400;
        private static SpellSlot Ignite;

        private static Menu MainMenu;
        private static AIHeroClient Player { get { return ObjectManager.Player; } }
        static void Main(string[] args)
        {
            GameEvent.OnGameLoad += GameEventOnOnGameLoad;
        }

        private static void GameEventOnOnGameLoad()
        {
            if (Player.CharacterName != "Yasuo") return;
            Chat.Print("<font color=\"#008aff\">WindWalker Yasuo</font> ver 1.0 by <font color=\"#FF0000\"> xDreamms</font> - <font color=\"#00BFFF\">Loaded</font>");
            InitSpells();
            InitMenu();
            Game.OnTick += GameOnOnUpdate;
            Drawing.OnDraw += DrawingOnOnDraw;
            // AIHeroClient.OnProcessSpellCast += AiHeroClientOnOnProcessSpellCast;
            Game.OnWndProc += GameOnOnWndProc;
        }

        private static void GameOnOnWndProc(WndEventArgs args)
        {
            if (args.Msg != 0x20a)
                return;
            MainMenu["Combo"]["ComboEGapTower"].GetValue<MenuBool>().SetValue(!ComboEGapTower);

        }
        /*
        private static void AiHeroClientOnOnProcessSpellCast(AIBaseClient sender, AIBaseClientProcessSpellCastEventArgs args)
        {
           
            if (MiscUseW && sender.IsEnemy && !sender.IsMinion && sender.Distance(Player.Position) <= Q2Range )
            {
                if (WBlockSpellDatabase.DangerousList.Any(spell => spell.Contains(args.SData.Name)))
                {
                    W.Cast(Player.Position.Extend(args.Start, 100));
                }
            }
        }*/

        private static void InitMenu()
        {
            MainMenu = new Menu("WindWalkerYasuo", "WindWalker Yasuo", true);
            {
                var comboMenu = new Menu("Combo", "Combo");
                {
                    comboMenu.Add(new MenuSeparator("ComboQSettings", "Q Settings"));
                    Helper.AddMenuBool(comboMenu, "ComboQ", "Use Q");
                    Helper.AddMenuBool(comboMenu, "ComboQ3", "Use Q3");
                    Helper.AddMenuBool(comboMenu, "ComboQTower", "Use Q under turret");
                    Helper.AddMenuBool(comboMenu, "ComboQStack", "-> Stack Q While Gap (E Gap Must On)", false);
                    comboMenu.Add(new MenuSeparator("ComboESettings", "E Settings"));
                    Helper.AddMenuBool(comboMenu, "ComboE", "Use E");
                    Helper.AddMenuBool(comboMenu, "ComboEDmg", "-> Q3 Circle (Q Must On)");
                    Helper.AddMenuBool(comboMenu, "ComboEGap", "-> Gap Closer");
                    Helper.AddMenuSlider(comboMenu, "ComboEGapRange", "-> If Enemy Not In", 300, 1, 475);
                    Helper.AddMenuBool(comboMenu, "ComboEGapTower", "-> Under Tower (On/Off: Mouse Scroll)", false);
                    comboMenu.Add(new MenuSeparator("ComboRSettings", "R Settings"));
                    Helper.AddMenuBool(comboMenu, "ComboR", "Use R");
                    Helper.AddMenuBool(comboMenu, "ComboRDelay", "R Delay");
                    comboMenu.Add(new MenuList("ComboRMode", "Select R mode",
                        new[] { "Only if target killable", "Instant Ulti" }, 1));
                    MainMenu.Add(comboMenu);
                }
                var harassMenu = new Menu("Harass", "Harass");
                {
                    harassMenu.Add(new MenuSeparator("HarassQSettings", "Q Settings"));
                    Helper.AddMenuKeyBind(harassMenu, "HarassAutoQ", "Auto Q", Keys.H, KeyBindType.Toggle);
                    Helper.AddMenuBool(harassMenu, "HarassAutoQTower", "-> Under Tower", false);
                    Helper.AddMenuBool(harassMenu, "HarassAutoQ3", "-> Use Q3", false);
                    Helper.AddMenuBool(harassMenu, "HarassQ", "Use Q");
                    Helper.AddMenuBool(harassMenu, "HarassQTower", "Use Q Tower", false);
                    Helper.AddMenuBool(harassMenu, "HarassQ3", "-> Use Q3");
                    Helper.AddMenuBool(harassMenu, "HarassQStack", "-> Stack Q While Gap (E Gap Must On)");
                    Helper.AddMenuBool(harassMenu, "HarassQLastHit", "-> Last Hit (Q1/Q2)");
                    harassMenu.Add(new MenuSeparator("HarassESettings", "E Settings"));
                    Helper.AddMenuBool(harassMenu, "HarassE", "-> Use E", false);
                    Helper.AddMenuBool(harassMenu, "HarassEGap", "-> Gap Closer");
                    Helper.AddMenuBool(harassMenu, "HarassEGapTower", "-> Under Tower");
                    Helper.AddMenuBool(harassMenu, "HarassEDmg", "-> Q3 Circle (Q Must On)");
                    Helper.AddMenuSlider(harassMenu, "HarassEGapRange", "-> If Enemy Not In", 300, 1, 475);
                    MainMenu.Add(harassMenu);
                }
                var clearMenu = new Menu("Clear", "Clear");
                {
                    Helper.AddMenuBool(clearMenu, "ClearQ", "Use Q");
                    Helper.AddMenuBool(clearMenu, "ClearQ3", "-> Use Q3");
                    Helper.AddMenuBool(clearMenu, "ClearE", "Use E");
                    Helper.AddMenuBool(clearMenu, "ClearETower", "-> Under Tower", false);
                    MainMenu.Add(clearMenu);
                }
                var lastHitMenu = new Menu("LastHit", "LastHit");
                {
                    Helper.AddMenuBool(lastHitMenu, "LastHitQ", "Use Q");
                    Helper.AddMenuBool(lastHitMenu, "LastHitQ3", "-> Use Q3", false);
                    Helper.AddMenuBool(lastHitMenu, "LastHitE", "Use E");
                    Helper.AddMenuBool(lastHitMenu, "LastHitETower", "-> Under Tower", false);
                    MainMenu.Add(lastHitMenu);
                }
                var fleeMenu = new Menu("Flee", "Flee");
                {
                    Helper.AddMenuKeyBind(fleeMenu, "FleeZ", "Flee !", Keys.Z, KeyBindType.Press);
                    Helper.AddMenuBool(fleeMenu, "FleeEStackQ", "-> Stack Q While Dashing");
                    MainMenu.Add(fleeMenu);
                }
                var killStealMenu = new Menu("KillSteal", "KillSteal");
                {
                    Helper.AddMenuBool(killStealMenu, "KillStealQ", "Use Q");
                    Helper.AddMenuBool(killStealMenu, "KillStealE", "Use E");
                    Helper.AddMenuBool(killStealMenu, "KillStealR", "Use R");
                    Helper.AddMenuBool(killStealMenu, "KillStealIgnite", "Use Ignite");
                    MainMenu.Add(killStealMenu);
                }
                var miscMenu = new Menu("Misc", "Misc");
                {
                    Helper.AddMenuKeyBind(miscMenu, "MiscStackQ", "Auto Stack Q", Keys.A, KeyBindType.Toggle);
                    Helper.AddMenuBool(miscMenu, "MiscStackQDraw", "-> Draw Text");
                    //Helper.AddMenuBool(miscMenu, "MiscUseW", "-> Use W to block dangerous Skillshots BETA");
                    MainMenu.Add(miscMenu);
                }
                var drawMenu = new Menu("Draw", "Drawings");
                {
                    Helper.AddMenuBool(drawMenu, "DrawQ", "Draw Q", true);
                    Helper.AddMenuBool(drawMenu, "DrawE", "Draw E", true);
                    Helper.AddMenuBool(drawMenu, "DrawR", "Draw R", true);
                    MainMenu.Add(drawMenu);
                }
                MainMenu.Attach();
            }
        }

        private static void InitSpells()
        {
            Q = new Spell(SpellSlot.Q, 500);
            Q2 = new Spell(SpellSlot.Q, 1100);
            W = new Spell(SpellSlot.W, 400);
            E = new Spell(SpellSlot.E, 475);
            R = new Spell(SpellSlot.R, 1300);
            R.SetSkillshot(0.70f, 125f, float.MaxValue, false, false, SkillshotType.Circle);

            Ignite = Player.GetSpellSlot("summonerdot");
            Q.SetSkillshot(GetQDelay, 20, float.MaxValue, false, false, SkillshotType.Line);
            Q2.SetSkillshot(GetQ2Delay, 90, 1500, false, false, SkillshotType.Line);
            E.SetTargetted(0.05f, 1000);
        }
        public static bool CastIgnite(AIHeroClient target)
        {
            return Ignite.IsReady() && target.IsValidTarget(600)
                   && target.Health + 5 < Player.GetSummonerSpellDamage(target, SummonerSpell.Ignite)
                   && Player.Spellbook.CastSpell(Ignite, target);
        }
        private static void DrawingOnOnDraw(EventArgs args)
        {
            if (Player.IsDead)
            {
                return;
            }
            if (MiscStackQ && MiscStackQDraw)
            {
                var pos = Drawing.WorldToScreen(Player.Position);
                Drawing.DrawText(pos.X, pos.Y, System.Drawing.Color.Orange, "Auto Stack Q");
            }
            if (HarassAutoQ)
            {
                var pos = Drawing.WorldToScreen(Player.Position);
                Drawing.DrawText(pos.X, pos.Y + 20, System.Drawing.Color.Red, "Auto Q");
            }
            if (ComboEGapTower)
            {
                var pos = Drawing.WorldToScreen(Player.Position);
                Drawing.DrawText(pos.X, pos.Y + 40, System.Drawing.Color.Blue, "Combo E Under Tower");
            }
            if (DrawQ && Q.Level > 0)
            {
                Render.Circle.DrawCircle(
                    Player.Position,
                    Player.IsDashing() ? QCirWidth : (!HaveQ3 ? Q : Q2).Range,
                    Q.IsReady() ? System.Drawing.Color.Green : System.Drawing.Color.Red);
            }
            if (DrawE && E.Level > 0)
            {
                Render.Circle.DrawCircle(Player.Position, E.Range, E.IsReady() ? System.Drawing.Color.Green : System.Drawing.Color.Red);
            }
            if (DrawR && R.Level > 0)
            {
                Render.Circle.DrawCircle(Player.Position, R.Range, R.IsReady() ? System.Drawing.Color.Green : System.Drawing.Color.Red);
            }
        }

        private static void GameOnOnUpdate(EventArgs args)
        {
            if (!Equals(Q.Delay, GetQDelay))
            {
                Q.Delay = GetQDelay;
            }
            if (!Equals(Q2.Delay, GetQ2Delay))
            {
                Q2.Delay = GetQ2Delay;
            }
            if (Player.IsDead || MenuGUI.IsChatOpen || Player.IsRecalling())
            {
                return;
            }
            if (Orbwalker.ActiveMode == OrbwalkerMode.Combo)
            {
                Combo();
            }
            if (Orbwalker.ActiveMode == OrbwalkerMode.LaneClear)
            {
                Clear();
            }
            if (Orbwalker.ActiveMode == OrbwalkerMode.LastHit)
            {
                LastHit();
            }
            if (Orbwalker.ActiveMode == OrbwalkerMode.Harass)
            {
                Harass();
            }
            if (FleeZ)
            {
                Flee();
            }
            AutoQ();
            StackQ();
            KillSteal();
        }

        private static void Harass()
        {


            if (HarassE && E.IsReady())
            {
                if (HarassEDmg && HarassQ && HaveQ3 && Q.IsReady(50))
                {
                    var target = TargetSelector.GetTarget(QRange, DamageType.Physical);
                    if (target != null)
                    {
                        var obj = GetNearObj(target, true);
                        if (obj != null && E.CastOnUnit(obj))
                        {
                            return;
                        }
                    }
                }
                if (HarassEGap)
                {
                    var target = TargetSelector.GetTarget(QRange, DamageType.Physical)
                                 ?? TargetSelector.GetTarget(Q2Range, DamageType.Physical);
                    if (target != null)
                    {
                        var obj = GetNearObj(target);
                        if (obj != null
                            && (obj.NetworkId != target.NetworkId
                                    ? Player.Distance(target) > HarassEGapRange
                                    : !target.InAutoAttackRange())
                            && (!UnderTower(PosAfterE(obj)) || HarassEGapTower)
                            && E.CastOnUnit(obj))
                        {
                            return;
                        }
                    }
                }
            }

            if (HarassQ && Q.IsReady())
            {
                if (((!HaveQ3 || HarassQ3)
                        && (!UnderTower(Player.Position) || HarassQTower)))
                {
                    if (Player.IsDashing())
                    {
                        if (QCirTarget != null && CastQCir(QCirTarget))
                        {
                            return;
                        }
                        if (!HaveQ3 && HarassQStack && HarassE
                            && HarassEGap && Q.GetTarget(200) == null)
                        {
                            var minionObj = GameObjects.EnemyMinions.Where(x =>
                                x.IsValidTarget(QCirWidth, true, Player.GetDashInfo().EndPos.ToVector3()) && x.IsEnemy);
                            if (minionObj.Any() && Player.Distance(Player.GetDashInfo().EndPos) < 150
                                && CastQCir(minionObj.MinOrDefault(i => i.Distance(Player))))
                            {
                                return;
                            }
                        }
                    }
                    else
                    {
                        var target = TargetSelector.GetTarget(
                            !HaveQ3 ? QRange : Q2Range,
                            DamageType.Physical);
                        if (target != null)
                        {
                            if (!HaveQ3)
                            {
                                if (Q.Cast(target))
                                {
                                    return;
                                }
                            }
                            else
                            {
                                var hit = -1;
                                var predPos = new Vector3();
                                foreach (var hero in GameObjects.EnemyHeroes.Where(i => i.IsValidTarget(Q2Range)))
                                {
                                    var pred = Q2.GetPrediction(hero, true);
                                    if (pred.Hitchance >= HitChance.VeryHigh && pred.AoeTargetsHitCount > hit)
                                    {
                                        hit = pred.AoeTargetsHitCount;
                                        predPos = pred.CastPosition;
                                    }
                                }
                                if (predPos.IsValid())
                                {
                                    if (Q2.Cast(predPos))
                                    {
                                        return;
                                    }
                                }
                                else if (Q2.Cast(target))
                                {
                                    return;
                                }
                            }
                        }
                    }
                }

            }

        }

        private static void KillSteal()
        {
            if (KillStealIgnite && Ignite.IsReady())
            {
                var target = TargetSelector.GetTarget(600, DamageType.True);
                if (target != null && CastIgnite(target))
                {
                    return;
                }
            }
            if (KillStealQ && Q.IsReady())
            {
                if (Player.IsDashing())
                {
                    var target = QCirTarget;
                    if (target != null && CanKill(target, GetQDmg(target)) && CastQCir(target))
                    {
                        return;
                    }
                }
                else
                {
                    var target = TargetSelector.GetTarget(
                        !HaveQ3 ? QRange : Q2Range,
                        DamageType.Physical);
                    if (target != null && CanKill(target, GetQDmg(target))
                        && (!HaveQ3 ? Q : Q2).Cast(target))
                    {
                        return;
                    }
                }
            }
            if (KillStealE && E.IsReady())
            {
                var target = E.GetTarget(0, GameObjects.EnemyHeroes.Where(i => !CanCastE(i)));
                if (target != null
                    && (CanKill(target, GetEDmg(target))
                        || (KillStealQ && Q.IsReady(50)
                            && CanKill(target, GetEDmg(target) + GetQDmg(target)))) && E.CastOnUnit(target))
                {
                    return;
                }
            }
            if (KillStealR && R.IsReady())
            {
                var target = R.GetTarget(0, GameObjects.EnemyHeroes.Where(i => !CanCastR(i)));
                if (target != null && IsKillable(target, SpellSlot.R))
                {
                    R.CastOnUnit(target);
                }
            }
        }

        private static void Flee()
        {
            ObjectManager.Player.IssueOrder(GameObjectOrder.MoveTo, Game.CursorPosCenter);

            if (!FleeZ)
            {
                return;
            }
            if (FleeEStackQ && Q.IsReady() && !HaveQ3 && Player.IsDashing())
            {
                if (QCirTarget != null && CastQCir(QCirTarget))
                {
                    return;
                }
                var minionObj = ObjectManager.Get<AIMinionClient>().Where(x =>
                    x.IsValidTarget(QCirWidth, true, Player.GetDashInfo().EndPos.ToVector3()) && x.IsEnemy);

                if (minionObj.Any() && Player.Distance(Player.GetDashInfo().EndPos) < 150
                    && CastQCir(minionObj.MinOrDefault(i => i.Distance(Player))))
                {
                    return;
                }
            }
            var obj = GetNearObj();
            if (obj == null || !E.IsReady())
            {
                return;
            }
            E.CastOnUnit(obj);
        }

        private static void LastHit()
        {
            if (LastHitQ && Q.IsReady() && !Player.IsDashing()
                && (!HaveQ3 || LastHitQ3))
            {
                var obj = ObjectManager.Get<AIMinionClient>().Where(x =>
                        x.IsValidTarget(!HaveQ3 ? QRange : Q2Range) && x.IsEnemy).OrderBy(a => a.MaxHealth)
                    .FirstOrDefault(p => CanKill(p, GetQDmg(p)));
                if (obj != null && (!HaveQ3 ? Q : Q2).Cast(obj))
                {
                    return;
                }
            }
            if (LastHitE && E.IsReady())
            {
                var obj =
                    ObjectManager.Get<AIMinionClient>().Where(x =>
                            x.IsValidTarget(!HaveQ3 ? QRange : Q2Range) && x.IsEnemy).OrderBy(a => a.MaxHealth)
                        .Where(
                            i =>
                                CanCastE(i)
                                && (!i.IsValidTarget(Player.GetRealAutoAttackRange()) || i.Health > Player.GetAutoAttackDamage(i))
                                && (!UnderTower(PosAfterE(i)) || LastHitETower))
                        .FirstOrDefault(i => CanKill(i, GetEDmg(i)));
                if (obj != null)
                {
                    E.CastOnUnit(obj);
                }
            }
        }

        private static void Clear()
        {
            if (ClearE && E.IsReady())
            {

                var minionObj = ObjectManager.Get<AIMinionClient>().Where(x => x.IsValidTarget(E.Range) && x.IsEnemy)
                    .Where(i => CanCastE(i) && (!UnderTower(PosAfterE(i)) || ClearETower))
                    .ToList();

                if (minionObj.Any())
                {
                    var obj = minionObj.FirstOrDefault(i => CanKill(i, GetEDmg(i)));
                    if (obj == null && ClearQ && Q.IsReady(50)
                        && (!HaveQ3 || ClearQ3))
                    {
                        obj = (from i in minionObj
                               let sub = ObjectManager.Get<AIMinionClient>().Where(x =>
                                   x.IsValidTarget(QCirWidth, true, PosAfterE(x)) && x.IsEnemy)
                               where
                                   i.Team == GameObjectTeam.Neutral
                                   || (i.Distance(PosAfterE(i)) < QCirWidthMin && CanKill(i, GetEDmg(i) + GetQDmg(i)))
                                   || sub.Any(a => CanKill(a, GetQDmg(a))) || sub.Count() > 1
                               select i).MaxOrDefault(
                            i => ObjectManager.Get<AIMinionClient>()
                                .Where(x => x.IsValidTarget(QCirWidth, true, PosAfterE(x)) && x.IsEnemy).Count());
                    }
                    if (obj != null && E.CastOnUnit(obj))
                    {
                        return;
                    }
                }
            }
            if (ClearQ && Q.IsReady() && (!HaveQ3 || ClearQ3))
            {
                if (Player.IsDashing())
                {
                    var minionObj = ObjectManager.Get<AIMinionClient>()
                        .Where(x => x.IsValidTarget(QCirWidth, true, Player.GetDashInfo().EndPos.ToVector3()) &&
                                    x.IsEnemy);

                    if ((minionObj.Any(i => CanKill(i, GetQDmg(i)) || i.Team == GameObjectTeam.Neutral)
                         || minionObj.Count() > 1) && Player.Distance(Player.GetDashInfo().EndPos) < 150
                        && CastQCir(minionObj.MinOrDefault(i => i.Distance(Player))))
                    {
                        return;
                    }
                }
                else
                {
                    var minionObj = ObjectManager.Get<AIMinionClient>()
                        .Where(x => x.IsValidTarget(!HaveQ3 ? QRange : Q2Range) && x.IsEnemy).OrderBy(a => a.MaxHealth);

                    if (minionObj.Any())
                    {
                        if (!HaveQ3)
                        {
                            var obj = minionObj.FirstOrDefault(i => CanKill(i, GetQDmg(i)));
                            if (obj != null && Q.Cast(obj))
                            {
                                return;
                            }
                        }
                        var qMinHit = Q.MinHitChance;
                        Q.MinHitChance = HitChance.Medium;
                        var pos = (!HaveQ3 ? Q : Q2).GetLineFarmLocation(minionObj.Cast<AIBaseClient>().ToList());
                        Q.MinHitChance = qMinHit;
                        if (pos.MinionsHit > 0 && (!HaveQ3 ? Q : Q2).Cast(pos.Position))
                        {
                            return;
                        }
                    }
                }
            }

        }

        public static bool IsKillable(AIBaseClient target, SpellSlot slot)
        {
            return ObjectManager.Player.GetSpellDamage(target, slot) > target.Health;
        }

        private static void Combo()
        {
            var t = TargetSelector.GetTarget(R.Range);

            if (t != null)
            {
                if (CanCastR(t))
                {
                    if (ComboRMode == "Only if target killable")
                    {
                        if (t != null && R.IsReady() && t.IsValidTarget(R.Range) && IsKillable(t, SpellSlot.R))
                        {
                            if (ComboRDelay)
                            {
                                if (TimeLeftR(t) * 1000 < 150 + Game.Ping * 2)
                                    R.Cast(t);
                            }
                            else
                            {
                                R.Cast(t);
                            }

                        }
                    }
                    else
                    {
                        if (t != null && R.IsReady() && t.IsValidTarget(R.Range))
                        {

                            if (ComboRDelay)
                            {
                                if (TimeLeftR(t) * 1000 < 150 + Game.Ping * 2)
                                    R.Cast(t);
                            }
                            else
                            {
                                R.Cast(t);
                            }
                        }
                    }
                }

            }
            if (ComboE && E.IsReady())
            {
                if (ComboEDmg && ComboQ && HaveQ3 && Q.IsReady(50))
                {
                    var target = TargetSelector.GetTarget(QRange, DamageType.Physical);
                    if (target != null)
                    {
                        var obj = GetNearObj(target, true);
                        if (obj != null && E.CastOnUnit(obj))
                        {
                            return;
                        }
                    }
                }
                if (ComboEGap)
                {
                    var target = TargetSelector.GetTarget(QRange, DamageType.Physical)
                                 ?? TargetSelector.GetTarget(Q2Range, DamageType.Physical);
                    if (target != null)
                    {
                        var obj = GetNearObj(target);
                        if (obj != null
                            && (obj.NetworkId != target.NetworkId
                                    ? Player.Distance(target) > ComboEGapRange
                                    : !target.InAutoAttackRange())
                            && (!UnderTower(PosAfterE(obj)) || ComboEGapTower)
                            && E.CastOnUnit(obj))
                        {
                            return;
                        }
                    }
                }
            }

            if (ComboQ && Q.IsReady())
            {
                if (((!HaveQ3 || ComboQ3)
                        && (!UnderTower(Player.Position) || ComboQTower)))
                {
                    if (Player.IsDashing())
                    {
                        if (QCirTarget != null && CastQCir(QCirTarget))
                        {
                            return;
                        }
                        if (!HaveQ3 && ComboQStack && ComboE
                            && ComboEGap && Q.GetTarget(200) == null)
                        {
                            var minionObj = GameObjects.EnemyMinions.Where(x =>
                                x.IsValidTarget(QCirWidth, true, Player.GetDashInfo().EndPos.ToVector3()) && x.IsEnemy);
                            if (minionObj.Any() && Player.Distance(Player.GetDashInfo().EndPos) < 150
                                && CastQCir(minionObj.MinOrDefault(i => i.Distance(Player))))
                            {
                                return;
                            }
                        }
                    }
                    else
                    {
                        var target = TargetSelector.GetTarget(
                            !HaveQ3 ? QRange : Q2Range,
                            DamageType.Physical);
                        if (target != null)
                        {
                            if (!HaveQ3)
                            {
                                if (Q.Cast(target))
                                {
                                    return;
                                }
                            }
                            else
                            {
                                var hit = -1;
                                var predPos = new Vector3();
                                foreach (var hero in GameObjects.EnemyHeroes.Where(i => i.IsValidTarget(Q2Range)))
                                {
                                    var pred = Q2.GetPrediction(hero, true);
                                    if (pred.Hitchance >= HitChance.VeryHigh && pred.AoeTargetsHitCount > hit)
                                    {
                                        hit = pred.AoeTargetsHitCount;
                                        predPos = pred.CastPosition;
                                    }
                                }
                                if (predPos.IsValid())
                                {
                                    if (Q2.Cast(predPos))
                                    {
                                        return;
                                    }
                                }
                                else if (Q2.Cast(target))
                                {
                                    return;
                                }
                            }
                        }
                    }
                }

            }
        }


        private static float GetQ2Delay
        {
            get
            {
                return 0.5f * (1 - Math.Min((Player.AttackSpeedMod - 1) * 0.58f, 0.66f));
            }
        }

        private static float GetQDelay
        {
            get
            {
                return 0.4f * (1 - Math.Min((Player.AttackSpeedMod - 1) * 0.58f, 0.66f));
            }
        }

        private static bool HaveQ3
        {
            get { return Q.Name == "YasuoQ3Wrapper"; }
        }

        private static AIHeroClient QCirTarget
        {
            get
            {
                var pos = Player.GetDashInfo().EndPos.ToVector3();
                // var target = TargetSelector.GetTarget(QCirWidth, TargetSelector.DamageType.Physical, true, null, pos);
                var target = ObjectManager.Get<AIHeroClient>().Where(x => x.IsValidTarget(QCirWidth, true, pos) && !x.IsAlly && !x.IsZombie).FirstOrDefault();
                return target != null && Player.Distance(pos) < 150 ? target : null;
            }
        }
        private static void AutoQ()
        {
            if (!HarassAutoQ || Player.IsDashing()
                || (HaveQ3 && !HarassAutoQ3)
                || (UnderTower(Player.Position) && !HarassAutoQTower))
            {
                return;
            }
            var target = TargetSelector.GetTarget(!HaveQ3 ? QRange : Q2Range, DamageType.Physical);
            if (target == null)
            {
                return;
            }
            (!HaveQ3 ? Q : Q2).Cast(target);
        }

        private static bool UnderTower(Vector3 pos)
        {
            return
                ObjectManager.Get<AITurretClient>()
                    .Any(i => i.IsEnemy && !i.IsDead && i.Distance(pos) < 850 + Player.BoundingRadius);
        }
        private static bool CanCastE(AIBaseClient target)
        {
            return !target.HasBuff("YasuoDashWrapper");
        }

        private static bool CanCastR(AIHeroClient target)
        {
            return target.HasBuffOfType(BuffType.Knockup) || target.HasBuffOfType(BuffType.Knockback);
        }

        private static bool CastQCir(AIBaseClient target)
        {
            return target.IsValidTarget(QCirWidthMin - target.BoundingRadius) && Q.Cast(Game.CursorPosCenter);
        }
        private static double GetEDmg(AIBaseClient target)
        {
            return Player.CalculateDamage(
                target,
                DamageType.Magical,
                (50 + 20 * E.Level) * (1 + Math.Max(0, Player.GetBuffCount("YasuoDashScalar") * 0.25))
                + 0.6 * Player.FlatMagicDamageMod);
        }

        private static AIBaseClient GetNearObj(AIBaseClient target = null, bool inQCir = false)
        {
            var pos = target != null
                          ? SpellPrediction.GetPrediction(target, E.Delay, 0, E.Speed).UnitPosition
                          : Game.CursorPosCenter;
            var obj = new List<AIBaseClient>();
            obj.AddRange(ObjectManager.Get<AIMinionClient>().Where(i => i.IsValidTarget(E.Range) && !i.IsAlly));
            obj.AddRange(ObjectManager.Get<AIHeroClient>().Where(i => i.IsValidTarget(E.Range) && !i.IsAlly));
            return
                obj.Where(
                    i =>
                    CanCastE(i) && pos.Distance(PosAfterE(i)) < (inQCir ? QCirWidthMin : Player.Distance(pos))
                    )
                    .MinOrDefault(i => pos.Distance(PosAfterE(i)));
        }

        private static double GetQDmg(AIBaseClient target)
        {
            return Player.GetSpellDamage(target, SpellSlot.Q);
        }
        private static Vector3 PosAfterE(AIBaseClient target)
        {
            return Player.Position.Extend(
                target.Position,
                Player.Distance(target) < 410 ? E.Range : Player.Distance(target) + 65);
        }
        private static void StackQ()
        {
            if (!MiscStackQ || !Q.IsReady() || Player.IsDashing() || HaveQ3)
            {
                return;
            }
            var target = Q.GetTarget();
            if (target != null && (!UnderTower(Player.Position) || !UnderTower(target.Position)))
            {
                Q.CastIfHitchanceEquals(target, HitChance.VeryHigh);
            }
            else
            {
                var minionObj = ObjectManager.Get<AIMinionClient>().Where(i => i.IsValidTarget(E.Range) && i.IsEnemy)
                    .OrderBy(a => a.MaxHealth);
                if (!minionObj.Any())
                {
                    return;
                }
                var obj = minionObj.FirstOrDefault(i => CanKill(i, GetQDmg(i)))
                          ?? minionObj.MinOrDefault(i => i.Distance(Player));
                if (obj != null)
                {
                    Q.CastIfHitchanceEquals(obj, HitChance.VeryHigh);
                }
            }
        }
        public static bool CanKill(AIBaseClient target, double subDmg)
        {
            return target.Health < subDmg;
        }
        private static float TimeLeftR(AIHeroClient target)
        {
            var buff = target.Buffs.FirstOrDefault(i => i.Type == BuffType.Knockback || i.Type == BuffType.Knockup);
            return buff != null ? buff.EndTime - Game.Time : -1;
        }
        public static bool ComboQ
        {
            get { return Helper.GetMenuBoolValue(MainMenu, "Combo", "ComboQ"); }
        }

        //ComboQTower
        public static bool ComboQ3 { get { return Helper.GetMenuBoolValue(MainMenu, "Combo", "ComboQ3"); } }
        public static bool ComboQTower { get { return Helper.GetMenuBoolValue(MainMenu, "Combo", "ComboQTower"); } }
        public static string ComboRMode
        {
            get
            {
                return MainMenu["Combo"]["ComboRMode"].GetValue<MenuList>().SelectedValue;
            }
        }
        public static bool ComboQStack { get { return Helper.GetMenuBoolValue(MainMenu, "Combo", "ComboQStack"); } }
        public static bool ComboE { get { return Helper.GetMenuBoolValue(MainMenu, "Combo", "ComboE"); } }
        public static bool ComboEDmg { get { return Helper.GetMenuBoolValue(MainMenu, "Combo", "ComboEDmg"); } }
        public static bool ComboEGap { get { return Helper.GetMenuBoolValue(MainMenu, "Combo", "ComboEGap"); } }
        public static int ComboEGapRange { get { return Helper.GetMenuSliderValue(MainMenu, "Combo", "ComboEGapRange"); } }
        public static bool ComboEGapTower { get { return Helper.GetMenuBoolValue(MainMenu, "Combo", "ComboEGapTower"); } }
        public static bool ComboR { get { return Helper.GetMenuBoolValue(MainMenu, "Combo", "ComboR"); } }
        public static bool ComboRDelay { get { return Helper.GetMenuBoolValue(MainMenu, "Combo", "ComboRDelay"); } }
        public static int ComboRHpU { get { return Helper.GetMenuSliderValue(MainMenu, "Combo", "ComboRHpU"); } }
        public static int ComboRCountA { get { return Helper.GetMenuSliderValue(MainMenu, "Combo", "ComboRCountA"); } }

        public static bool HarassAutoQ { get { return Helper.GetMenuKeyBindValue(MainMenu, "Harass", "HarassAutoQ"); } }
        public static bool HarassAutoQ3 { get { return Helper.GetMenuBoolValue(MainMenu, "Harass", "HarassAutoQ3"); } }
        public static bool HarassAutoQTower { get { return Helper.GetMenuBoolValue(MainMenu, "Harass", "HarassAutoQTower"); } }
        public static bool HarassQ { get { return Helper.GetMenuBoolValue(MainMenu, "Harass", "HarassQ"); } }
        public static bool HarassQ3 { get { return Helper.GetMenuBoolValue(MainMenu, "Harass", "HarassQ3"); } }
        public static bool HarassQStack { get { return Helper.GetMenuBoolValue(MainMenu, "Harass", "HarassQStack"); } }
        public static bool HarassQLastHit { get { return Helper.GetMenuBoolValue(MainMenu, "Harass", "HarassQLastHit"); } }
        public static bool HarassE { get { return Helper.GetMenuBoolValue(MainMenu, "Harass", "HarassE"); } }


        public static bool HarassQTower { get { return Helper.GetMenuBoolValue(MainMenu, "Harass", "HarassQTower"); } }

        public static bool HarassEGap { get { return Helper.GetMenuBoolValue(MainMenu, "Harass", "HarassEGap"); } }
        public static bool HarassEGapTower { get { return Helper.GetMenuBoolValue(MainMenu, "Harass", "HarassEGapTower"); } }
        public static bool HarassEDmg { get { return Helper.GetMenuBoolValue(MainMenu, "Harass", "HarassEDmg"); } }
        public static int HarassEGapRange { get { return Helper.GetMenuSliderValue(MainMenu, "Harass", "HarassEGapRange"); } }



        public static bool ClearQ { get { return Helper.GetMenuBoolValue(MainMenu, "Clear", "ClearQ"); } }
        public static bool ClearQ3 { get { return Helper.GetMenuBoolValue(MainMenu, "Clear", "ClearQ3"); } }
        public static bool ClearE { get { return Helper.GetMenuBoolValue(MainMenu, "Clear", "ClearE"); } }
        public static bool ClearETower { get { return Helper.GetMenuBoolValue(MainMenu, "Clear", "ClearETower"); } }
        public static bool ClearItem { get { return Helper.GetMenuBoolValue(MainMenu, "Clear", "ClearItem"); } }


        public static bool LastHitQ { get { return Helper.GetMenuBoolValue(MainMenu, "LastHit", "LastHitQ"); } }
        public static bool LastHitQ3 { get { return Helper.GetMenuBoolValue(MainMenu, "LastHit", "LastHitQ3"); } }
        public static bool LastHitE { get { return Helper.GetMenuBoolValue(MainMenu, "LastHit", "LastHitE"); } }
        public static bool LastHitETower { get { return Helper.GetMenuBoolValue(MainMenu, "LastHit", "LastHitETower"); } }
        public static bool FleeZ { get { return Helper.GetMenuKeyBindValue(MainMenu, "Flee", "FleeZ"); } }
        public static bool FleeEStackQ { get { return Helper.GetMenuBoolValue(MainMenu, "Flee", "FleeEStackQ"); } }

        public static bool KillStealQ { get { return Helper.GetMenuBoolValue(MainMenu, "KillSteal", "KillStealQ"); } }
        public static bool KillStealE { get { return Helper.GetMenuBoolValue(MainMenu, "KillSteal", "KillStealE"); } }
        public static bool KillStealR { get { return Helper.GetMenuBoolValue(MainMenu, "KillSteal", "KillStealR"); } }
        public static bool KillStealIgnite { get { return Helper.GetMenuBoolValue(MainMenu, "KillSteal", "KillStealIgnite"); } }
        public static bool MiscStackQ { get { return Helper.GetMenuKeyBindValue(MainMenu, "Misc", "MiscStackQ"); } }
        public static bool MiscStackQDraw { get { return Helper.GetMenuBoolValue(MainMenu, "Misc", "MiscStackQDraw"); } }
        //  public static bool MiscUseW { get { return Helper.GetMenuBoolValue(MainMenu, "Misc", "MiscUseW"); } }

        public static bool DrawQ { get { return Helper.GetMenuBoolValue(MainMenu, "Draw", "DrawQ"); } }
        public static bool DrawE { get { return Helper.GetMenuBoolValue(MainMenu, "Draw", "DrawE"); } }
        public static bool DrawR { get { return Helper.GetMenuBoolValue(MainMenu, "Draw", "DrawR"); } }


    }
}
