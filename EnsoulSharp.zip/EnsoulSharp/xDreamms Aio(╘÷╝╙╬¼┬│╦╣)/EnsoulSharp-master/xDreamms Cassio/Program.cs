﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EnsoulSharp;
using EnsoulSharp.SDK;
using EnsoulSharp.SDK.MenuUI.Values;
using EnsoulSharp.SDK.Prediction;
using EnsoulSharp.SDK.Utility;
using SharpDX;
using Menu = EnsoulSharp.SDK.MenuUI.Menu;

namespace xDreamms_Cassio
{
    class Program
    {
        public const string ChampionName = "Cassiopeia";
        public static Menu Option;
        public static List<Spell> SpellList = new List<Spell>();
        public static Spell Q;
        public static Spell W;
        public static Spell E;
        public static Spell R;
        private static SpellSlot Ignite;
        private static long LastQCast = 0;
        private static long LastECast = 0;
        public static HitChance Chance = HitChance.VeryHigh;
        public static bool listed = true;
        public static bool Nopsntarget = true;
        public static bool aastatus;
        public static int kills = 0;
        public static Random rand = new Random();

        public static List<string> Messages;
        private static Menu Config;
        private static AIHeroClient Player { get { return ObjectManager.Player; } }
        static void Main(string[] args)
        {
            GameEvent.OnGameLoad += GameEventOnOnGameLoad;
        }

        private static void GameEventOnOnGameLoad()
        {
            if (Player.CharacterName != ChampionName) return;
            CreateSpells();
            CreateMenu();
            CreateEvents();
        }

        private static void CreateEvents()
        {
            Game.OnTick += GameOnOnUpdate;
            Drawing.OnDraw += DrawingOnOnDraw;
            Spellbook.OnCastSpell += SpellbookOnOnCastSpell;
            Chat.Print("<font color=\"#008aff\">xDreamms Cassiopeia by </font> <font color=\"#FF0000\"> xDreams</font> - <font color=\"#00BFFF\">Loaded</font>");

        }
        private static void SpellbookOnOnCastSpell(Spellbook sender, SpellbookCastSpellEventArgs args)
        {
            if (args.Slot == SpellSlot.Q)
                LastQCast = Variables.TickCount;
            if (args.Slot == SpellSlot.E)
                LastECast = Variables.TickCount;
        }

        private static void DrawingOnOnDraw(EventArgs args)
        {
            if (DrawQ)
                Render.Circle.DrawCircle(ObjectManager.Player.Position, Q.Range, System.Drawing.Color.Yellow);
            if (DrawW)
                Render.Circle.DrawCircle(ObjectManager.Player.Position, W.Range, System.Drawing.Color.Purple);
            if (DrawE)
                Render.Circle.DrawCircle(ObjectManager.Player.Position, E.Range, System.Drawing.Color.Red);
            if (DrawR)
                Render.Circle.DrawCircle(ObjectManager.Player.Position, R.Range, System.Drawing.Color.Blue);
        }

        private static void GameOnOnUpdate(EventArgs args)
        {
            try
            {

                switch (Orbwalker.ActiveMode)
                {
                    case OrbwalkerMode.Combo:
                        Combo();
                        break;
                    case OrbwalkerMode.Harass:
                        Harass();
                        break;
                    case OrbwalkerMode.LaneClear:
                        JungleClear();
                        WaveClear();
                        break;
                    case OrbwalkerMode.LastHit:
                        Freeze();
                        break;
                    default:
                        break;
                }
                if (MiscAutoUlt)
                {
                    CastAutoUltimate();
                }
                if (ComboAssistedUltKey)
                {
                    CastAssistedUlt();
                }
                if (KillStealIgnite || KillStealQ || KillStealE || KillStealR)
                {
                    KillSteal();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        private static void KillSteal()
        {
            if (KillStealIgnite && Ignite.IsReady())
            {
                var target = TargetSelector.GetTarget(600, DamageType.True);
                if (target != null && CastIgnite(target))
                {
                    return;
                }
            }
            if (KillStealQ && Q.IsReady())
            {
                var target = GameObjects.EnemyHeroes.Where(x =>
                    x.IsValidTarget(Q.Range) && x.IsEnemy && Player.GetSpellDamage(x, SpellSlot.Q) > x.Health).FirstOrDefault();
              
                if (target != null)
                    Q.Cast(PreCastPos(target, 0.6f));

            }
            if (KillStealE && E.IsReady())
            {
                var target = GameObjects.EnemyHeroes.Where(x =>
                    x.IsValidTarget(E.Range) && x.IsEnemy && Player.GetSpellDamage(x, SpellSlot.E) > x.Health).FirstOrDefault();
                if (target != null)
                {

                    if (Variables.TickCount >= LastECast + (ComboEdelay * 100))
                        E.Cast(target);
                }
            }
            if (KillStealR && R.IsReady())
            {
                var target = GameObjects.EnemyHeroes.Where(x =>
                    x.IsValidTarget(R.Range) && x.IsEnemy && Player.GetSpellDamage(x, SpellSlot.R) > x.Health && R.WillHit(x, R.GetPrediction(x, true).CastPosition)).FirstOrDefault();
                R.Cast(R.GetPrediction(target, true).CastPosition);

            }
        }

        public static void CastAssistedUlt()
        {
            ObjectManager.Player.IssueOrder(GameObjectOrder.MoveTo, Game.CursorPosCenter);

            var faceEnemy = ObjectManager.Get<AIHeroClient>().Where(enemy => enemy.IsValidTarget() && enemy.IsFacing(Player) && R.WillHit(enemy, R.GetPrediction(enemy, true).CastPosition)).ToList();
            var Enemy = ObjectManager.Get<AIHeroClient>().Where(enemy => enemy.IsValidTarget() && R.WillHit(enemy, R.GetPrediction(enemy, true).CastPosition)).ToList();

            if (faceEnemy.Count() >= 1 && GetRFaceTarget() != null)
            {
                R.Cast(R.GetPrediction(GetRFaceTarget(), true).CastPosition);
            }
            else
            if (Enemy.Count >= 1 && GetRTarget() != null)
            {
                R.Cast(R.GetPrediction(GetRTarget(), true).CastPosition);
            }
        }
        private static void Freeze()
        {
            var elasthit = LastHitE;
            if (!Player.CanMove) return;
            if (LastHitDisableAA)
            {
                Orbwalker.AttackState = false;
            }
            else
            {
                Orbwalker.AttackState = true;
            }
            
            if (E.IsReady())
            {
                var MinionListE = GameObjects.EnemyMinions.Where(x => x.IsValidTarget(E.Range) && x.IsEnemy)
                    .OrderBy(x => x.MaxHealth);

                foreach (var minion in MinionListE.Where(x => Player.GetSpellDamage(x, SpellSlot.E) > x.Health))
                {
                    if ((minion.HasBuffOfType(BuffType.Poison) && (GetPoisonBuffEndTime(minion) > Game.Time + E.Delay)) || elasthit)
                    {
                        E.Cast(minion);
                    }

                }
            }
        }

        private static void WaveClear()
        {
            if (!Player.CanMove) return;

            var allMinionsQ = GameObjects.EnemyMinions.Where(x => x.IsValidTarget(Q.Range + Q.Width) && x.IsEnemy)
                .ToList();
            var allMinionsW = GameObjects.EnemyMinions.Where(x => x.IsValidTarget(W.Range + W.Width) && x.IsEnemy)
                .ToList();
            var allMinionsQnopsn = GameObjects.EnemyMinions.Where(x=> x.IsValidTarget(Q.Range + Q.Width) && x.IsEnemy).Where(x => !x.HasBuffOfType(BuffType.Poison) || GetPoisonBuffEndTime(x) <= (Game.Time + Q.Delay)).ToList();
            var rangedMinionsQnopsn = GameObjects.EnemyMinions.Where(x => x.IsValidTarget(Q.Range + Q.Width)&& x.IsEnemy && x.IsRanged).Where(x => !x.HasBuffOfType(BuffType.Poison) || GetPoisonBuffEndTime(x) <= (Game.Time + Q.Delay)).ToList();
            var allMinionsWnopsn = GameObjects.EnemyMinions.Where(x => x.IsValidTarget(W.Range + W.Width) && x.IsEnemy).Where(x => !x.HasBuffOfType(BuffType.Poison) || GetPoisonBuffEndTime(x) <= (Game.Time + W.Delay)).ToList();
            var rangedMinionsWnopsn = GameObjects.EnemyMinions.Where(x => x.IsValidTarget(Q.Range + Q.Width) && x.IsEnemy && x.IsRanged).Where(x => !x.HasBuffOfType(BuffType.Poison) || GetPoisonBuffEndTime(x) <= (Game.Time + W.Delay)).ToList();
            
            var Qlaneclear = LaneClearQ;
            var Wlaneclear = LaneClearW;

            if (allMinionsQnopsn.Count() == allMinionsQ.Count())
                Nopsntarget = true;
            else
                Nopsntarget = false;

            if (Q.IsReady() && allMinionsQnopsn.Count() == allMinionsQ.Count() && Qlaneclear)
            {
                var FLr = Q.GetCircularFarmLocation(rangedMinionsQnopsn, Q.Width);
                var FLa = Q.GetCircularFarmLocation(allMinionsQnopsn, Q.Width);

                if (FLr.MinionsHit >= 3 && Player.Distance(FLr.Position) < (Q.Range + Q.Width))
                {
                    Q.Cast(FLr.Position);
                    return;
                }
                else
                    if (FLa.MinionsHit >= 2 || allMinionsQnopsn.Count() == 1 && Player.Distance(FLr.Position) < (Q.Range + Q.Width))
                {
                    Q.Cast(FLa.Position);
                    return;
                }
            }

            if (W.IsReady() && allMinionsWnopsn.Count() == allMinionsW.Count() && Wlaneclear && Variables.TickCount > (LastQCast + Q.Delay * 1000))
            {
                var FLr = W.GetCircularFarmLocation(rangedMinionsWnopsn, W.Width);
                var FLa = W.GetCircularFarmLocation(allMinionsWnopsn, W.Width);

                if (FLr.MinionsHit >= 3 && Player.Distance(FLr.Position) < (W.Range + W.Width))
                {
                    W.Cast(FLr.Position);
                    return;
                }
                else
                    if (FLa.MinionsHit >= 2 || allMinionsWnopsn.Count() == 1 && Player.Distance(FLr.Position) < (W.Range + W.Width))
                {
                    W.Cast(FLa.Position);
                    return;
                }
            }

            if (E.IsReady())
            {
                var MinionList = GameObjects.EnemyMinions.Where(x=>x.IsValidTarget(E.Range) && x.IsEnemy).OrderBy(x=> x.MaxHealth);

                foreach (var minion in MinionList.Where(x => x.HasBuffOfType(BuffType.Poison)))
                {
                    var buffEndTime = GetPoisonBuffEndTime(minion);
                    if (buffEndTime > Game.Time + E.Delay)
                    {
                        if (Player.GetSpellDamage(minion, SpellSlot.E) > minion.Health || Player.ManaPercent > LaneClearMana)
                        {
                            E.Cast(minion);
                        }
                    }
                }
            }
        }

        public static void JungleClear()
        {
            var mobs = GameObjects.Jungle.Where(x => x.IsValidTarget(Q.Range) && x.Team == GameObjectTeam.Neutral)
                .OrderBy(x => x.MaxHealth);
            if (!mobs.Any())
                return;

            var mob = mobs.First();

            if (Q.IsReady() && mob.IsValidTarget(Q.Range))
            {
                Q.Cast(mob.Position);
            }

            if (E.IsReady() && mob.HasBuffOfType(BuffType.Poison) && mob.IsValidTarget(E.Range))
            {
                if (Variables.TickCount >= LastECast + (ComboEdelay * 100))
                    E.Cast(mob);
            }

            if (W.IsReady() && mob.IsValidTarget(W.Range) && Variables.TickCount > LastQCast + Q.Delay * 1000 && LaneClearW)
            {
                W.Cast(mob.Position);
            }

        }

        private static void Harass()
        {
            var target = TargetSelector.GetTarget(Q.Range, DamageType.Magical);
            if(target == null)return;
            if (E.IsReady()&& HarassE && target.IsValidTarget(E.Range))
            {
                    if (Variables.TickCount >= LastECast + (10 * 100))
                        E.Cast(target);
            }

            if (Q.IsReady() && HarassQ)
            {
                    Q.Cast(PreCastPos(target, 0.7f));

            }
            if (W.IsReady() && Variables.TickCount > LastQCast + Q.Delay * 1000 && HarassW && target.IsValidTarget(W.Range))
            {
                    W.Cast(PreCastPos(target, Player.Position.Distance(target.Position) / W.Speed));

            }
        }

        private static void Combo()
        {
            var target = TargetSelector.GetTarget(Q.Range, DamageType.Magical);
            if(target == null)return;
            if (ComboDisableAA)
            {
                Orbwalker.AttackState = false;
            }
            else
            {
                Orbwalker.AttackState = true;
            }
            if (E.IsReady() && ComboE && target.IsValidTarget(E.Range))
            {
                    if (ComboEOnlyPoison)
                    {
                        if (Variables.TickCount >= LastECast + (ComboEdelay * 100)&& (target.HasBuffOfType(BuffType.Poison) && (GetPoisonBuffEndTime(target) > Game.Time + E.Delay)))
                            E.Cast(target);
                    }
                    else
                    {
                        if (Variables.TickCount >= LastECast + (ComboEdelay * 100))
                            E.Cast(target);
                    }
            }

            if (Q.IsReady() &&  ComboQ)
            {
                Q.Cast(PreCastPos(target, 0.5f));
            }
            if (W.IsReady() && Variables.TickCount > LastQCast + Q.Delay * 1000 && ComboW && target.IsValidTarget(W.Range))
            {
                    W.Cast(PreCastPos(target, Player.Position.Distance(target.Position) / W.Speed));
               
            }
            if (R.IsReady() && ComboR && Variables.TickCount > LastQCast + Q.Delay * 1000)
            {
                if ( GetRFaceTarget() != null)
                {
                    R.Cast(R.GetPrediction(GetRFaceTarget(), true).CastPosition);
                }
            }

        }
        public static void CastAutoUltimate()
        {
            var faceEnemy = ObjectManager.Get<AIHeroClient>().Where(enemy => enemy.IsValidTarget() && enemy.IsFacing(Player) && R.WillHit(enemy, R.GetPrediction(enemy, true).CastPosition)).ToList();
            var Enemy = ObjectManager.Get<AIHeroClient>().Where(enemy => enemy.IsValidTarget() && R.WillHit(enemy, R.GetPrediction(enemy, true).CastPosition)).ToList();

            var AutoUltF = MiscAutoUltF;
            var AutoUltnF = MiscAutoUltnF;

            if (faceEnemy.Count() >= AutoUltF && GetRFaceTarget() != null)
            {
                R.Cast(R.GetPrediction(GetRFaceTarget(), true).CastPosition);
            }
            else
            if (Enemy.Count >= AutoUltnF && GetRTarget() != null)
            {
                R.Cast(R.GetPrediction(GetRTarget(), true).CastPosition);
            }

        }
        private static AIHeroClient GetRTarget()
        {
            var Enemy = ObjectManager.Get<AIHeroClient>().Where(enemy => enemy.IsValidTarget() && R.WillHit(enemy, R.GetPrediction(enemy, true).CastPosition)).ToList();
            
                    foreach (var enemy in Enemy)
                        if (enemy != null && enemy.IsVisible && !enemy.IsDead)
                        {
                                return enemy;
                        }
            
            return null;
        }
        private static AIHeroClient GetRFaceTarget()
        {
            var FaceEnemy = ObjectManager.Get<AIHeroClient>().Where(enemy => enemy.IsValidTarget(R.Range) && enemy.IsFacing(Player) && R.WillHit(enemy, R.GetPrediction(enemy, true).CastPosition)).ToList();
           
                    foreach (var fenemy in FaceEnemy)
                        if (fenemy != null && fenemy.IsVisible && !fenemy.IsDead)
                        {
                                return fenemy;
                        }
            return null;

        }

        private static Vector3 PreCastPos(AIHeroClient Hero, float Delay)
        {
            float value = 0f;
            if (Hero.IsFacing(Player))
            {
                value = (50f - Hero.BoundingRadius);
            }
            else
            {
                value = -(100f - Hero.BoundingRadius);
            }
            var distance = Delay * Hero.MoveSpeed + value;
            var path = Hero.GetWaypoints();

            for (var i = 0; i < path.Count - 1; i++)
            {
                var a = path[i];
                var b = path[i + 1];
                var d = a.Distance(b);

                if (d < distance)
                {
                    distance -= d;
                }
                else
                {
                    return (a + distance * (b - a).Normalized()).ToVector3();
                }
            }


            return (path[path.Count - 1]).ToVector3();
        }
        private static float GetPoisonBuffEndTime(AIBaseClient target)
        {
            var buffEndTime = target.Buffs.OrderByDescending(buff => buff.EndTime - Game.Time)
                .Where(buff => buff.Type == BuffType.Poison)
                .Select(buff => buff.EndTime)
                .FirstOrDefault();
            return buffEndTime;
        }
        private static void CreateMenu()
        {
            Config = new Menu("xDreammsCassio", "xDreamms Cassiopeia",true);

            var comboMenu = new Menu("Combo", "Combo");
            Helper.AddMenuBool(comboMenu, "ComboQ", "Use Q");
            Helper.AddMenuBool(comboMenu, "ComboW", "Use W");
            Helper.AddMenuBool(comboMenu, "ComboE", "Use E");
            Helper.AddMenuBool(comboMenu,"ComboEOnlyPoison","Use E only if target has poison");
            Helper.AddMenuSlider(comboMenu, "ComboEdelay", "Ecombo delay", 0, 0, 20);
            Helper.AddMenuBool(comboMenu, "ComboR", "Use R");
            Helper.AddMenuBool(comboMenu,"ComboDisableAA","Disable AA when Combo",false);
            Helper.AddMenuKeyBind(comboMenu, "ComboAssistedUltKey", "Manuel Ult", Keys.A, KeyBindType.Press);
            Config.Add(comboMenu);

            //Harass Menu
            var harassMenu = new Menu("Harass", "Harass");
            Helper.AddMenuBool(harassMenu, "HarassQ", "Use Q");
            Helper.AddMenuBool(harassMenu, "HarassW", "Use W");
            Helper.AddMenuBool(harassMenu, "HarassE", "Use E");
            Config.Add(harassMenu);

            //LaneClear
            var lClearMenu = new Menu("LaneClear", "LaneClear");
            Helper.AddMenuBool(lClearMenu, "LaneClearQ", "Use Q");
            Helper.AddMenuBool(lClearMenu, "LaneClearW", "Use W");
            Helper.AddMenuSlider(lClearMenu, "LaneClearMana", "Lane Clear Mana", 70,0,100);
            Config.Add(lClearMenu);

            //LastHit
            var lHitMenu = new Menu("LastHit", "LastHit");
            Helper.AddMenuBool(lHitMenu, "LastHitE", "Use E");
            Helper.AddMenuBool(lHitMenu, "LastHitDisableAA", "Disable AA");
            Config.Add(lHitMenu);

            //Misc
            var miscMenu = new Menu("Misc", "Misc");
            Helper.AddMenuBool(miscMenu, "MiscBlockR", "BlockR");
            Helper.AddMenuBool(miscMenu, "MiscAutoUlt", "AutoUltimate");
            Helper.AddMenuSlider(miscMenu, "MiscAutoUltF", "AutoUlt facing", 3, 0, 5);
            Helper.AddMenuSlider(miscMenu, "MiscAutoUltnF", "AutoUlt not facing", 5, 0, 5);
            Config.Add(miscMenu);
            // KillSteal Menu
            var KillStealMenu = new Menu("KillSteal", "KillSteal");
            Helper.AddMenuBool(KillStealMenu, "KillStealIgnite", "KillSteal with Ignite");
            Helper.AddMenuBool(KillStealMenu, "KillStealQ", "KillSteal with Q");
            Helper.AddMenuBool(KillStealMenu, "KillStealE", "KillSteal with E");
            Helper.AddMenuBool(KillStealMenu, "KillStealR", "KillSteal with R",false);
            Config.Add(KillStealMenu);


            //Draw Menu
            var drawMenu = new Menu("Drawings", "Drawings");
            Helper.AddMenuBool(drawMenu, "DrawQ", "Draw Q");
            Helper.AddMenuBool(drawMenu, "DrawW", "Draw W");
            Helper.AddMenuBool(drawMenu, "DrawE", "Draw E");
            Helper.AddMenuBool(drawMenu, "DrawR", "Draw R");
            Config.Add(drawMenu);
            Config.Attach();
          
        }

        private static void CreateSpells()
        {
            Q = new Spell(SpellSlot.Q, 830f);
            Q.SetSkillshot(0.75f, Q.Instance.SData.CastRadius, float.MaxValue, false, false, SkillshotType.Circle);

            W = new Spell(SpellSlot.W, 850f);
            W.SetSkillshot(0.5f, W.Instance.SData.CastRadius, W.Instance.SData.MissileSpeed, false, false, SkillshotType.Circle);

            E = new Spell(SpellSlot.E, 700f);
            E.SetTargetted(0.2f, float.MaxValue);

            R = new Spell(SpellSlot.R, 825f);
            R.SetSkillshot(0.3f, (float)(80 * Math.PI / 180), float.MaxValue, false, false, SkillshotType.Cone);
            Ignite = Player.GetSpellSlot("summonerdot");
           
            SpellList.Add(Q);
            SpellList.Add(W);
            SpellList.Add(E);
            SpellList.Add(R);
        }
        public static bool CastIgnite(AIHeroClient target)
        {
            return Ignite.IsReady() && target.IsValidTarget(600)
                   && target.Health + 5 < Player.GetSummonerSpellDamage(target, SummonerSpell.Ignite)
                   && Player.Spellbook.CastSpell(Ignite, target);
        }
        public static bool ComboQ { get { return Helper.GetMenuBoolValue(Config, "Combo", "ComboQ"); } }
        public static bool ComboW { get { return Helper.GetMenuBoolValue(Config, "Combo", "ComboW"); } }
        public static bool ComboE { get { return Helper.GetMenuBoolValue(Config, "Combo", "ComboE"); } }
        public static bool ComboEOnlyPoison { get { return Helper.GetMenuBoolValue(Config, "Combo", "ComboEOnlyPoison"); } }

        
        public static int ComboEdelay { get { return Helper.GetMenuSliderValue(Config, "Combo", "ComboEdelay"); } }
        public static bool ComboR { get { return Helper.GetMenuBoolValue(Config, "Combo", "ComboR"); } }
        public static bool ComboDisableAA { get { return Helper.GetMenuBoolValue(Config, "Combo", "ComboDisableAA"); } }

        
        public static bool ComboAssistedUltKey { get { return Helper.GetMenuKeyBindValue(Config, "Combo", "ComboAssistedUltKey"); } }

        public static bool HarassQ { get { return Helper.GetMenuBoolValue(Config, "Harass", "HarassQ"); } }
        public static bool HarassW { get { return Helper.GetMenuBoolValue(Config, "Harass", "HarassW"); } }
        public static bool HarassE { get { return Helper.GetMenuBoolValue(Config, "Harass", "HarassE"); } }
        public static bool LaneClearQ { get { return Helper.GetMenuBoolValue(Config, "LaneClear", "LaneClearQ"); } }
        public static bool LaneClearW { get { return Helper.GetMenuBoolValue(Config, "LaneClear", "LaneClearW"); } }
        public static int LaneClearMana { get { return Helper.GetMenuSliderValue(Config, "LaneClear", "LaneClearMana"); } }
        public static bool LastHitE { get { return Helper.GetMenuBoolValue(Config, "LastHit", "LastHitE"); } }
        
        public static bool LastHitDisableAA { get { return Helper.GetMenuBoolValue(Config, "LastHit", "LastHitDisableAA"); } }

        public static bool KillStealIgnite { get { return Helper.GetMenuBoolValue(Config, "KillSteal", "KillStealIgnite"); } }
        public static bool KillStealQ { get { return Helper.GetMenuBoolValue(Config, "KillSteal", "KillStealQ"); } }
        public static bool KillStealE { get { return Helper.GetMenuBoolValue(Config, "KillSteal", "KillStealE"); } }
        public static bool KillStealR { get { return Helper.GetMenuBoolValue(Config, "KillSteal", "KillStealR"); } }

        public static bool MiscBlockR { get { return Helper.GetMenuBoolValue(Config, "Misc", "MiscBlockR"); } }
        public static bool MiscAutoUlt { get { return Helper.GetMenuBoolValue(Config, "Misc", "MiscAutoUlt"); } }
        public static int MiscAutoUltF { get { return Helper.GetMenuSliderValue(Config, "Misc", "MiscAutoUltF"); } }
        public static int MiscAutoUltnF { get { return Helper.GetMenuSliderValue(Config, "Misc", "MiscAutoUltnF"); } }
        public static bool DrawQ { get { return Helper.GetMenuBoolValue(Config, "Drawings", "DrawQ"); } }
        public static bool DrawW { get { return Helper.GetMenuBoolValue(Config, "Drawings", "DrawW"); } }
        public static bool DrawE { get { return Helper.GetMenuBoolValue(Config, "Drawings", "DrawE"); } }
        public static bool DrawR { get { return Helper.GetMenuBoolValue(Config, "Drawings", "DrawR"); } }


      


    }
}
