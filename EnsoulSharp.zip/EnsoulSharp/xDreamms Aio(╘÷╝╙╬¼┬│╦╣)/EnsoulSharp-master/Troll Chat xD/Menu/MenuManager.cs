﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EnsoulSharp.SDK.MenuUI.Values;
using Troll_Chat_xD.Core;
using Troll_Chat_xD.Helper;

namespace Troll_Chat_xD.Menu
{
    public class MenuManager : Troll
    {
        public static EnsoulSharp.SDK.MenuUI.Menu Config;

        public static void LoadMenu()
        {
            Config = new EnsoulSharp.SDK.MenuUI.Menu("TrollChat", "Troll Chat xD", true);
            Config.Add(TrollMenu());
            Config.Attach();
        }

        public static EnsoulSharp.SDK.MenuUI.Menu TrollMenu()
        {
            var menu = new EnsoulSharp.SDK.MenuUI.Menu("Settings", "Settings");
            menu.AddMenuKeybind("PrintGG", "Print GG", Keys.A, KeyBindType.Toggle);
            menu.AddMenuKeybind("PrintWP", "Print WP", Keys.D, KeyBindType.Toggle);
            menu.AddMenuKeybind("PrintMiddleFinger", "Print Middle Finger", Keys.C, KeyBindType.Toggle);
            menu.AddMenuKeybind("PrintXD", "Print XD", Keys.E, KeyBindType.Toggle);


            return menu;
        }
        public static bool PrintXD { get { return Config.GetMenuKeybind("Settings", "PrintXD"); } }

        public static bool PrintGG { get { return Config.GetMenuKeybind("Settings", "PrintGG"); } }
        public static bool PrintWP { get { return Config.GetMenuKeybind("Settings", "PrintWP"); } }
        public static bool PrintMiddleFinger { get { return Config.GetMenuKeybind("Settings", "PrintMiddleFinger"); } }

    }
}
