﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnsoulSharp;
using EnsoulSharp.SDK;
using Troll_Chat_xD.Helper;
using Troll_Chat_xD.Menu;

namespace Troll_Chat_xD.Event
{
    public class EventManager : MenuManager
    {
        public static void LoadEvents()
        {
            Game.OnTick += GameOnOnTick;
        }
        public static void PrintXD()
        {
            Chat.Say("##       ##   ########  ", true);
            Chat.Say(".##     ##    ##            ## ", true);
            Chat.Say("..##   ##     ##            ## ", true);
            Chat.Say(".....###        ##            ## ", true);
            Chat.Say("..##   ##     ##            ## ", true);
            Chat.Say(".##     ##    ##            ## ", true);
            Chat.Say("##       ##   ########  ", true);

        }
        public static void PrintMiddleFinger()
        {
            Chat.Say("....................../´¯/) ", true);
            Chat.Say("....................,/¯../ ", true);
            Chat.Say(".................../..../ ", true);
            Chat.Say("............./´¯/'...'/´¯¯`·¸ ", true);
            Chat.Say("........../'/.../..../......./¨¯\\ ", true);
            Chat.Say("........('(...´...´.... ¯~/'...') ", true);
            Chat.Say(".........\\.................'...../ ", true);
            Chat.Say("..........''...\\.......... _.·´ ", true);
        }

        public static void PrintWP()
        {
            Chat.Say("                            ", true);
            Chat.Say("#      #    ###### ", true);
            Chat.Say("#  #  #   #          #", true);
            Chat.Say("#  #  #   #          #", true);
            Chat.Say("#  #  #   ###### ", true);
            Chat.Say("#  #  #   #     ", true);
            Chat.Say("#  #  #   #     ", true);
            Chat.Say(" ## ##    #     ", true);
        }
        public static void PrintGG()
        {
            Chat.Say("                            ", true);
            Chat.Say("     #####      ##### ", true);
            Chat.Say(" #               #        ", true);
            Chat.Say(" #               #      ", true);
            Chat.Say(" #  ####   #  ####", true);
            Chat.Say(" #         #   #         #", true);
            Chat.Say(" #         #   #         #", true);
            Chat.Say("     #####      ##### ", true);

        }
        private static void GameOnOnTick(EventArgs args)
        {

            if (MenuManager.PrintGG)
            {
                PrintGG();
                Config.SetMenuKeybind("Settings", "PrintGG", false);
            }
            if (MenuManager.PrintMiddleFinger)
            {
                PrintMiddleFinger();
                Config.SetMenuKeybind("Settings", "PrintMiddleFinger", false);
            }
            if (MenuManager.PrintWP)
            {
                PrintWP();
                Config.SetMenuKeybind("Settings", "PrintWP", false);
            }
            if (MenuManager.PrintXD)
            {
                PrintXD();
                Config.SetMenuKeybind("Settings", "PrintXD", false);
            }
        }
    }
}
