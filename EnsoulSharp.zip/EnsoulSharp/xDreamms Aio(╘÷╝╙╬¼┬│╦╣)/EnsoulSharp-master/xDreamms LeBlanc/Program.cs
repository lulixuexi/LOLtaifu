﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnsoulSharp.SDK;
using xDreamms_LeBlanc.Constants;

namespace xDreamms_LeBlanc
{
    public class Program : LeBlanc
    {
        static void Main(string[] args)
        {
            GameEvent.OnGameLoad += GameEventOnOnGameLoad;
        }

        private static void GameEventOnOnGameLoad()
        {
            if (Player.CharacterName != CHAMP_NAME) return;
            OnLoad();
        }
    }
}
