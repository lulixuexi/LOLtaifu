﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnsoulSharp;
using EnsoulSharp.SDK;
using EnsoulSharp.SDK.MenuUI;
using EnsoulSharp.SDK.Prediction;
using xDreamms_LeBlanc.Events;
using xDreamms_LeBlanc.Spells;
using MenuManager = xDreamms_LeBlanc.Menu.MenuManager;

namespace xDreamms_LeBlanc.Constants
{
    public class LeBlanc
    {
        public static AIHeroClient Player { get { return ObjectManager.Player; } }
        public const string CHAMP_NAME = "Leblanc";
        public static GameObject WObject;
        public static GameObject RWObject;

        public static void OnLoad()
        {
            SpellManager.LoadSpells();
            MenuManager.LoadMenu();
            EventManager.LoadEvents();
        }
        public static Spell GetRSpell()
        {
            switch (SpellManager.R.Name)
            {
                case "LeblancRQ":
                    SpellManager.R = new Spell(SpellSlot.R, 700);
                    SpellManager.R.SetTargetted(0.25f, float.MaxValue);
                    break;
                case "LeblancRW":
                    SpellManager.R = new Spell(SpellSlot.R, 680);
                    SpellManager.R.SetSkillshot(0.25f, 80f, float.MaxValue, false, false, SkillshotType.Circle);
                    break;
                case "LeblancRE":
                    SpellManager.R = new Spell(SpellSlot.R, 950);
                    SpellManager.R.SetSkillshot(0.25f, 70f, 1750, true, true, SkillshotType.Line);
                    break;
            }
            return SpellManager.R;
        }
        public static bool TargetHasQ(AIHeroClient target)
        {
            return target.HasBuff("LeblancQMark");
        }
        public static bool TargetHasRQ(AIHeroClient target)
        {
            return target.HasBuff("LeblancRQMark");
        }
        public static bool WReturn()
        {
            return SpellManager.W.Name == "LeblancWReturn";
        }

        public static bool RReturn()
        {
            return SpellManager.R.Name == "LeblancRWReturn";
        }
        public static bool CastIgnite(AIHeroClient target)
        {
            return SpellManager.Ignite.IsReady() && target.IsValidTarget(600)
                   && target.Health + 5 < Player.GetSummonerSpellDamage(target, SummonerSpell.Ignite)
                   && Player.Spellbook.CastSpell(SpellManager.Ignite, target);
        }
        public static float GetComboDamage(AIHeroClient target)
        {
            var fComboDamage = 0f;

            if (!target.IsValidTarget(2000))
                return 0f;

            fComboDamage += SpellManager.Q.IsReady() ? (float)ObjectManager.Player.GetSpellDamage(target, SpellSlot.Q) : 0;

            fComboDamage += SpellManager.W.IsReady() ? (float)ObjectManager.Player.GetSpellDamage(target, SpellSlot.W) : 0;

            fComboDamage += SpellManager.E.IsReady() ? (float)ObjectManager.Player.GetSpellDamage(target, SpellSlot.E) : 0;
            //            menu.AddMenuList("ComboMode", "Combo Mode: ", new[] { "Q-R-W-E", "W-R-Q-E", "E-R-Q-W" }, 0);

            if (SpellManager.R.IsReady())
            {
                switch (MenuManager.ComboMode)
                {
                    case "Q-R-W-E":
                        fComboDamage += (float)ObjectManager.Player.GetSpellDamage(target, SpellSlot.Q);
                        break;
                    case "W-R-Q-E":
                        fComboDamage += (float)ObjectManager.Player.GetSpellDamage(target, SpellSlot.W);
                        break;
                    case "E-R-Q-W":
                        fComboDamage += (float)ObjectManager.Player.GetSpellDamage(target, SpellSlot.E);
                        break;
                }
            }

            fComboDamage += SpellManager.Ignite != SpellSlot.Unknown &&
                            ObjectManager.Player.Spellbook.CanUseSpell(SpellManager.Ignite) == SpellState.Ready
                ? (float)ObjectManager.Player.GetSummonerSpellDamage(target, SummonerSpell.Ignite)
                : 0f;

            return (float)fComboDamage;
        }
    }
}
