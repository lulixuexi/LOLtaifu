﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EnsoulSharp.SDK.MenuUI.Values;
using xDreamms_LeBlanc.Constants;
using xDreamms_LeBlanc.Helper;

namespace xDreamms_LeBlanc.Menu
{
    public class MenuManager : LeBlanc
    {
        public static EnsoulSharp.SDK.MenuUI.Menu Config;
        public static void LoadMenu()
        {
            Config = new EnsoulSharp.SDK.MenuUI.Menu("xDreammsLeblanc", "xDreamms Leblanc", true);
            Config.Add(ComboMenu());
            Config.Add(HarassMenu());
            Config.Add(LaneClearMenu());
            Config.Add(JungleClearMenu());
            Config.Add(LastHit());
            Config.Add(KillStealMenu());
            Config.Add(MiscMenu());
            Config.Add(FleeMenu());
            Config.Add(DrawMenu());
            Config.Attach();
        }
        public static EnsoulSharp.SDK.MenuUI.Menu ComboMenu()
        {
            var menu = new EnsoulSharp.SDK.MenuUI.Menu("Combo", "Combo");
            menu.AddMenuBool("ComboQ", "Use Q");
            menu.AddMenuBool("ComboW", "Use W");
            menu.AddMenuList("ComboWMode", "W mode: (Mouse Scroll to Change) ", new[] { "Only target", "Closer to the enemy" }, 0);
            menu.AddMenuBool("ComboE", "Use E");
            menu.AddMenuList("ComboMode", "Combo Mode: ", new[] { "Q-R-W-E", "W-R-Q-E", "E-R-Q-W" }, 0);
            menu.AddMenuKeybind("ChangeComboMode", "Change Combo Mode", Keys.A, KeyBindType.Press);
            return menu;
        }

        public static bool ComboQ { get { return Config.GetMenuBool("Combo", "ComboQ"); } }
        public static bool ComboW { get { return Config.GetMenuBool("Combo", "ComboW"); } }
        public static string ComboWMode { get { return Config.GetMenuList("Combo", "ComboWMode"); } }
        public static bool ComboE { get { return Config.GetMenuBool("Combo", "ComboE"); } }
        public static string ComboMode { get { return Config.GetMenuList("Combo", "ComboMode"); } }
        public static bool ChangeComboMode { get { return Config.GetMenuKeybind("Combo", "ChangeComboMode"); } }


        public static EnsoulSharp.SDK.MenuUI.Menu DrawMenu()
        {
            var menu = new EnsoulSharp.SDK.MenuUI.Menu("Draw", "Draw");
            menu.AddMenuBool("DrawQ", "Draw Q");
            menu.AddMenuBool("DrawW", "Draw W");
            menu.AddMenuBool("DrawE", "Draw E");
            menu.AddMenuBool("DrawWPosition", "Draw W Position");
            menu.AddMenuBool("DrawRWPosition", "Draw RW Position");
            menu.AddMenuBool("DrawComboMode", "Draw Combo Mode");
            menu.AddMenuBool("DrawComboWMode", "Draw Combo W Mode");
            menu.AddMenuBool("DrawDamage", "Draw Damage");

            return menu;
        }
        public static bool DrawQ { get { return Config.GetMenuBool("Draw", "DrawQ"); } }
        public static bool DrawW { get { return Config.GetMenuBool("Draw", "DrawW"); } }
        public static bool DrawE { get { return Config.GetMenuBool("Draw", "DrawE"); } }
        public static bool DrawWPosition { get { return Config.GetMenuBool("Draw", "DrawWPosition"); } }
        public static bool DrawRWPosition { get { return Config.GetMenuBool("Draw", "DrawRWPosition"); } }
        public static bool DrawDamage { get { return Config.GetMenuBool("Draw", "DrawDamage"); } }


        public static bool DrawComboMode { get { return Config.GetMenuBool("Draw", "DrawComboMode"); } }
        public static bool DrawComboWMode { get { return Config.GetMenuBool("Draw", "DrawComboWMode"); } }

        public static EnsoulSharp.SDK.MenuUI.Menu MiscMenu()
        {
            var menu = new EnsoulSharp.SDK.MenuUI.Menu("Misc", "Misc");
            menu.AddMenuBool("GapCloserE", "Use E Gapcloser");
            return menu;
        }
        public static bool GapCloserE { get { return Config.GetMenuBool("Misc", "GapCloserE"); } }


        public static EnsoulSharp.SDK.MenuUI.Menu HarassMenu()
        {
            var menu = new EnsoulSharp.SDK.MenuUI.Menu("Harass", "Harass");
            menu.AddMenuBool("HarassQ", "Use Q");
            menu.AddMenuBool("HarassW", "Use W");
            menu.AddMenuBool("HarassReturnBack", "Return Back W");
            menu.AddMenuBool("HarassE", "Use E");
            return menu;
        }
        public static bool HarassQ { get { return Config.GetMenuBool("Harass", "HarassQ"); } }
        public static bool HarassW { get { return Config.GetMenuBool("Harass", "HarassW"); } }
        public static bool HarassReturnBack { get { return Config.GetMenuBool("Harass", "HarassReturnBack"); } }
        public static bool HarassE { get { return Config.GetMenuBool("Harass", "HarassE"); } }



        public static EnsoulSharp.SDK.MenuUI.Menu LaneClearMenu()
        {
            var menu = new EnsoulSharp.SDK.MenuUI.Menu("LaneClear", "LaneClear");
            menu.AddMenuBool("LaneClearQ", "Use Q");
            menu.AddMenuBool("LaneClearW", "Use W");
            menu.AddMenuBool("LaneClearE", "Use E");
            menu.AddMenuBool("LaneClearR", "Use R");
            return menu;
        }
        public static bool LaneClearQ { get { return Config.GetMenuBool("LaneClear", "LaneClearQ"); } }
        public static bool LaneClearW { get { return Config.GetMenuBool("LaneClear", "LaneClearW"); } }
        public static bool LaneClearE { get { return Config.GetMenuBool("LaneClear", "LaneClearE"); } }
        public static bool LaneClearR { get { return Config.GetMenuBool("LaneClear", "LaneClearR"); } }

        public static EnsoulSharp.SDK.MenuUI.Menu LastHit()
        {
            var menu = new EnsoulSharp.SDK.MenuUI.Menu("LastHit", "LastHit");
            menu.AddMenuBool("LastHitQ", "Use Q");
            return menu;
        }
        public static bool LastHitQ { get { return Config.GetMenuBool("LastHit", "LastHitQ"); } }
        public static EnsoulSharp.SDK.MenuUI.Menu JungleClearMenu()
        {
            var menu = new EnsoulSharp.SDK.MenuUI.Menu("JungleClear", "JungleClear");
            menu.AddMenuBool("JungleClearQ", "Use Q");
            menu.AddMenuBool("JungleClearW", "Use W");
            menu.AddMenuBool("JungleClearE", "Use E");
            menu.AddMenuBool("JungleClearR", "Use R");
            return menu;
        }
        public static bool JungleClearQ { get { return Config.GetMenuBool("JungleClear", "JungleClearQ"); } }
        public static bool JungleClearW { get { return Config.GetMenuBool("JungleClear", "JungleClearW"); } }
        public static bool JungleClearE { get { return Config.GetMenuBool("JungleClear", "JungleClearE"); } }
        public static bool JungleClearR { get { return Config.GetMenuBool("JungleClear", "JungleClearR"); } }


        public static EnsoulSharp.SDK.MenuUI.Menu KillStealMenu()
        {
            var menu = new EnsoulSharp.SDK.MenuUI.Menu("KillSteal", "KillSteal");
            menu.AddMenuBool("KillStealQ", "Use Q");
            menu.AddMenuBool("KillStealW", "Use W");
            menu.AddMenuBool("KillStealE", "Use E");
            menu.AddMenuBool("KillStealIgnite", "Use Ignite");
            return menu;
        }
        public static bool KillStealQ { get { return Config.GetMenuBool("KillSteal", "KillStealQ"); } }
        public static bool KillStealW { get { return Config.GetMenuBool("KillSteal", "KillStealW"); } }
        public static bool KillStealE { get { return Config.GetMenuBool("KillSteal", "KillStealE"); } }
        public static bool KillStealIgnite { get { return Config.GetMenuBool("KillSteal", "KillStealIgnite"); } }

        public static EnsoulSharp.SDK.MenuUI.Menu FleeMenu()
        {
            var menu = new EnsoulSharp.SDK.MenuUI.Menu("Flee", "Flee");
            menu.AddMenuKeybind("FleeActive", "Flee !", Keys.Z, KeyBindType.Press);
            menu.AddMenuBool("FleeE", "Use E");
            menu.AddMenuBool("FleeR", "Use R");
            menu.AddMenuBool("FleeReturnBack", "Return back smartly");

            return menu;
        }
        public static bool FleeActive { get { return Config.GetMenuKeybind("Flee", "FleeActive"); } }
        public static bool FleeE { get { return Config.GetMenuBool("Flee", "FleeE"); } }
        public static bool FleeR { get { return Config.GetMenuBool("Flee", "FleeR"); } }
        public static bool FleeReturnBack { get { return Config.GetMenuBool("Flee", "FleeReturnBack"); } }



    }
}
