﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnsoulSharp.SDK.Prediction;
using xDreamms_LeBlanc.Helper;
using xDreamms_LeBlanc.Spells;

namespace xDreamms_LeBlanc.Modes
{
    public class LaneClearManager : SpellManager
    {
        public static void LaneClear()
        {
            var minions = Helper.MinionManager.GetEnemyMinions(Q.Range).OrderBy(x => x.MaxHealth);
            if (!minions.Any()) return;
            if (SpellHelper.SpellIsReadyAndActive(Q, LaneClearQ))
            {
                Helper.CastManager.CastTargeted(Q, minions.FirstOrDefault(), false);
            }
            if (SpellHelper.SpellIsReadyAndActive(W, LaneClearW) && !WReturn())
            {
                W.Cast(minions.FirstOrDefault());
            }
            if (SpellHelper.SpellIsReadyAndActive(R, LaneClearR) && !RReturn())
            {
                switch (R.Name)
                {
                    case "LeblancRQ":
                        GetRSpell().CastOnUnit(minions.FirstOrDefault());
                        break;
                    case "LeblancRW":
                        var minionCircular = GetRSpell().GetCircularFarmLocation(minions.ToList());
                        GetRSpell().Cast(minionCircular.Position);
                        break;
                    case "LeblancRE":
                        Helper.CastManager.CastSkillShot(GetRSpell(), HitChance.VeryHigh, minions.FirstOrDefault(), true);
                        break;
                }
            }
            if (SpellHelper.SpellIsReadyAndActive(E, LaneClearE))
            {
                Helper.CastManager.CastSkillShot(E, HitChance.VeryHigh, minions.FirstOrDefault(), false);
            }
        }
    }
}
