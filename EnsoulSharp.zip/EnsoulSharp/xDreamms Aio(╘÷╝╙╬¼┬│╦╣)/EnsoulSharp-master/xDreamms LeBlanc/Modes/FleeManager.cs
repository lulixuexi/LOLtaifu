﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnsoulSharp;
using EnsoulSharp.SDK;
using EnsoulSharp.SDK.Prediction;
using xDreamms_LeBlanc.Spells;

namespace xDreamms_LeBlanc.Modes
{
    public class FleeManager : SpellManager
    {
        public static void Flee()
        {
            Player.IssueOrder(GameObjectOrder.MoveTo, Game.CursorPosCenter);
            var target = TargetSelector.GetTarget(W.Range + E.Range);
            if (W.IsReady() && !WReturn())
            {
                W.Cast(Game.CursorPosCenter);
            }
            if (R.IsReady() && R.Name == "LeblancRW" && !RReturn())
            {
                R.Cast(Game.CursorPosCenter);
            }
            if (WReturn() && WObject.Distance(target.Position) - Player.Distance(target.Position) > 550 && FleeReturnBack)
            {
                W.Cast(target);
            }
            if (RReturn() && RWObject.Distance(target.Position) - Player.Distance(target.Position) > 550 && FleeReturnBack)
            {
                R.Cast(target);
            }
            if (E.IsReady() && FleeE)
            {
                Helper.CastManager.CastSkillShot(E, HitChance.VeryHigh, target, false);
            }
        }
    }
}
