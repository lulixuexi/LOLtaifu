﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnsoulSharp;
using EnsoulSharp.SDK;
using EnsoulSharp.SDK.Prediction;
using xDreamms_LeBlanc.Helper;
using xDreamms_LeBlanc.Spells;

namespace xDreamms_LeBlanc.Modes
{
    public class ComboManager : SpellManager
    {
        public static void Combo()
        {
            AIHeroClient target;
            if (ComboMode == "W-R-Q-E")
            {
                target = TargetSelector.GetTarget(W.Range * 2, DamageType.Magical);
            }
            else
            {
                target = TargetSelector.GetTarget(W.Range + E.Range);
            }
            if (target == null) return;
            switch (ComboMode)
            {
                case "Q-R-W-E":
                    switch (ComboWMode)
                    {
                        case "Closer to the enemy":
                            if (target.Distance(Player.Position) > W.Range)
                            {
                                if (SpellHelper.SpellIsReadyAndActive(W, ComboW) && !WReturn())
                                {
                                    var linePos = target.Position.Extend(Player.Position, -300);
                                    W.Cast(linePos);
                                }
                            }
                            break;
                    }
                    if (SpellHelper.SpellIsReadyAndActive(Q, ComboQ) && target.IsValidTarget(Q.Range))
                    {
                        Helper.CastManager.CastTargeted(Q, target);
                    }
                    if (R.IsReady() && !Q.IsReady() && !RReturn())
                    {
                        switch (R.Name)
                        {
                            case "LeblancRQ":
                                GetRSpell().CastOnUnit(target);
                                break;
                            case "LeblancRW":
                                Helper.CastManager.CastSkillShot(GetRSpell(), HitChance.VeryHigh, target, true);
                                break;
                            case "LeblancRE":
                                var pred = GetRSpell().GetPrediction(target, false, 0, CollisionObjects.Minions);
                                if (pred.Hitchance >= HitChance.High)
                                {
                                    GetRSpell().Cast(pred.CastPosition);
                                }
                                break;
                        }
                    }
                    if (SpellHelper.SpellIsReadyAndActive(W, ComboW) && target.IsValidTarget(W.Range)
                        && !WReturn() && !Q.IsReady() && (!R.IsReady() || RReturn()))
                    {
                        Helper.CastManager.CastSkillShot(W, HitChance.High, target, true);
                    }
                    if (SpellHelper.SpellIsReadyAndActive(E, ComboE) && target.IsValidTarget(E.Range)
                        && (!W.IsReady() || WReturn()) && (!R.IsReady() || RReturn()) && !Q.IsReady())
                    {
                        var pred = E.GetPrediction(target, false, 0, CollisionObjects.Minions);
                        if (pred.Hitchance >= HitChance.High)
                        {
                            E.Cast(pred.CastPosition);
                        }
                    }
                    break;

                case "W-R-Q-E":
                    switch (ComboWMode)
                    {
                        case "Only target":
                            if (SpellHelper.SpellIsReadyAndActive(W, ComboW) && target.IsValidTarget(W.Range) && !WReturn())
                            {
                                Helper.CastManager.CastSkillShot(W, HitChance.High, target, true);
                            }
                            break;
                        case "Closer to the enemy":
                            if (target.Distance(Player.Position) > W.Range)
                            {
                                if (SpellHelper.SpellIsReadyAndActive(W, ComboW) && !WReturn())
                                {
                                    var linePos = target.Position.Extend(Player.Position, -300);
                                    W.Cast(linePos);
                                }
                            }
                            break;
                    }

                    if (R.IsReady() && (!W.IsReady() || WReturn()) && !RReturn())
                    {
                        switch (R.Name)
                        {
                            case "LeblancRQ":
                                GetRSpell().CastOnUnit(target);
                                break;
                            case "LeblancRW":
                                Helper.CastManager.CastSkillShot(GetRSpell(), HitChance.High, target, true);
                                break;
                            case "LeblancRE":
                                var pred = GetRSpell().GetPrediction(target, false, 0, CollisionObjects.Minions);
                                if (pred.Hitchance >= HitChance.High)
                                {
                                    GetRSpell().Cast(pred.CastPosition);
                                }
                                break;
                        }
                    }
                    if (SpellHelper.SpellIsReadyAndActive(Q, ComboQ) && target.IsValidTarget(Q.Range)
                        && (!W.IsReady() || WReturn()) && (!R.IsReady() || RReturn()))
                    {
                        Helper.CastManager.CastTargeted(Q, target);
                    }

                    if (SpellHelper.SpellIsReadyAndActive(E, ComboE) && target.IsValidTarget(E.Range) && (!W.IsReady() || WReturn()) && (!R.IsReady() || RReturn()) && !Q.IsReady())
                    {
                        var pred = E.GetPrediction(target, false, 0, CollisionObjects.Minions);
                        if (pred.Hitchance >= HitChance.High)
                        {
                            E.Cast(pred.CastPosition);
                        }
                    }
                    break;
                case "E-R-Q-W":
                    switch (ComboWMode)
                    {
                        case "Closer to the enemy":
                            if (target.Distance(Player.Position) > W.Range)
                            {
                                if (SpellHelper.SpellIsReadyAndActive(W, ComboW) && !WReturn())
                                {
                                    var linePos = target.Position.Extend(Player.Position, -300);
                                    W.Cast(linePos);
                                }
                            }
                            break;
                    }
                    if (SpellHelper.SpellIsReadyAndActive(E, ComboE) && target.IsValidTarget(E.Range))
                    {
                        var pred = E.GetPrediction(target, false, 0, CollisionObjects.Minions);
                        if (pred.Hitchance >= HitChance.High)
                        {
                            E.Cast(pred.CastPosition);
                        }
                    }
                    if (R.IsReady() && !E.IsReady() && !RReturn())
                    {
                        switch (R.Name)
                        {
                            case "LeblancRQ":
                                GetRSpell().CastOnUnit(target);
                                break;
                            case "LeblancRW":
                                Helper.CastManager.CastSkillShot(GetRSpell(), HitChance.High, target, true);
                                break;
                            case "LeblancRE":
                                var pred = GetRSpell().GetPrediction(target, false, 0, CollisionObjects.Minions);
                                if (pred.Hitchance >= HitChance.High)
                                {
                                    GetRSpell().Cast(pred.CastPosition);
                                }
                                break;
                        }
                    }
                    if (SpellHelper.SpellIsReadyAndActive(Q, ComboQ) && target.IsValidTarget(Q.Range) && !E.IsReady() && (!R.IsReady() || RReturn()))
                    {
                        Helper.CastManager.CastTargeted(Q, target);
                    }
                    if (SpellHelper.SpellIsReadyAndActive(W, ComboE) && target.IsValidTarget(W.Range) && !E.IsReady() && (!R.IsReady() || RReturn()) && !Q.IsReady() && !WReturn())
                    {
                        Helper.CastManager.CastSkillShot(W, HitChance.High, target, true);
                    }
                    break;
            }
        }
    }
}
