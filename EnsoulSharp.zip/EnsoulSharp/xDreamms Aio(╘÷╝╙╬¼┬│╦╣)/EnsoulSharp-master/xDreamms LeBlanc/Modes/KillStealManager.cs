﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnsoulSharp;
using EnsoulSharp.SDK;
using EnsoulSharp.SDK.Prediction;
using xDreamms_LeBlanc.Helper;
using xDreamms_LeBlanc.Spells;

namespace xDreamms_LeBlanc.Modes
{
    public class KillStealManager : SpellManager
    {
        public static void KillSteal()
        {
            if (KillStealIgnite && Ignite.IsReady())
            {
                var target = TargetSelector.GetTarget(600, DamageType.True);
                if (target != null && CastIgnite(target))
                {
                    return;
                }
            }
            if (SpellHelper.SpellIsReadyAndActive(Q, KillStealQ))
            {
                var target = Helper.HeroManager.GetEnemyHeroes(Q.Range)
                    .Where(x => Player.GetSpellDamage(x, SpellSlot.Q) > x.Health).OrderBy(x => x.MaxHealth);
                if (target.Any())
                {
                    Helper.CastManager.CastTargeted(Q, target.FirstOrDefault(), false);
                }
            }
            if (SpellHelper.SpellIsReadyAndActive(W, KillStealW))
            {
                var target = Helper.HeroManager.GetEnemyHeroes(W.Range)
                    .Where(x => Player.GetSpellDamage(x, SpellSlot.W) > x.Health).OrderBy(x => x.MaxHealth);
                if (target.Any())
                {
                    Helper.CastManager.CastSkillShot(W, HitChance.VeryHigh, target.FirstOrDefault(), true);
                }
            }
            if (SpellHelper.SpellIsReadyAndActive(E, KillStealE))
            {
                var target = Helper.HeroManager.GetEnemyHeroes(E.Range)
                    .Where(x => Player.GetSpellDamage(x, SpellSlot.E) > x.Health).OrderBy(x => x.MaxHealth);
                if (target.Any())
                {
                    Helper.CastManager.CastSkillShot(E, HitChance.VeryHigh, target.FirstOrDefault(), true);
                }
            }
            if (SpellHelper.SpellIsReadyAndActive(Q, KillStealQ) &&
                SpellHelper.SpellIsReadyAndActive(E, KillStealE) &&
                SpellHelper.SpellIsReadyAndActive(W, KillStealW))
            {
                var target = Helper.HeroManager.GetEnemyHeroes(W.Range + E.Range).Where(x => QeDamage(x) > x.Health)
                    .OrderBy(x => x.MaxHealth);
                if (target.Any())
                {
                    var linepos = target.FirstOrDefault().Position.Extend(Player.Position, -700);
                    if (!WReturn())
                    {
                        W.Cast(linepos);
                    }
                    if (WReturn())
                    {
                        Helper.CastManager.CastSkillShot(Q, HitChance.VeryHigh, target.FirstOrDefault(), false);
                    }
                    if (!Q.IsReady() && WReturn())
                    {
                        Helper.CastManager.CastSkillShot(E, HitChance.VeryHigh, target.FirstOrDefault(), false);
                    }
                    if (target.FirstOrDefault().IsDead && WReturn())
                    {
                        W.Cast(target.FirstOrDefault());
                    }

                }
            }

        }

        public static double QeDamage(AIHeroClient target)
        {
            double damage = 0;
            if (Q.IsReady())
            {
                damage += Player.GetSpellDamage(target, SpellSlot.Q);
            }
            if (E.IsReady())
            {
                damage += Player.GetSpellDamage(target, SpellSlot.E);
            }
            return damage;
        }
    }
}
