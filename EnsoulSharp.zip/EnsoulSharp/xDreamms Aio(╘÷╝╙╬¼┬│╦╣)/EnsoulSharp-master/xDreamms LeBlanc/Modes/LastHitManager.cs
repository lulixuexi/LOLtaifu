﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnsoulSharp;
using EnsoulSharp.SDK;
using xDreamms_LeBlanc.Helper;
using xDreamms_LeBlanc.Spells;

namespace xDreamms_LeBlanc.Modes
{
    public class LastHitManager : SpellManager
    {
        public static void LastHit()
        {
            var minions = Helper.MinionManager.GetEnemyMinions(Q.Range).Where(x => Player.GetSpellDamage(x, SpellSlot.Q) > x.Health).OrderBy(x => x.MaxHealth);
            if (SpellHelper.SpellIsReadyAndActive(Q, LastHitQ))
            {
                Helper.CastManager.CastTargeted(Q, minions.FirstOrDefault(), false);
            }
        }
    }
}
