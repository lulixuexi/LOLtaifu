﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnsoulSharp;
using EnsoulSharp.SDK;
using EnsoulSharp.SDK.Prediction;
using xDreamms_LeBlanc.Helper;
using xDreamms_LeBlanc.Spells;

namespace xDreamms_LeBlanc.Modes
{
    public class HarassManager : SpellManager
    {
        public static void Harass()
        {
            var target = TargetSelector.GetTarget(Q.Range, DamageType.Magical);
            if (target == null) return;
            if (SpellHelper.SpellIsReadyAndActive(Q, HarassQ))
            {
                Helper.CastManager.CastTargeted(Q, target, false);
            }
            if (SpellHelper.SpellIsReadyAndActive(W, HarassW) && !WReturn() && target.IsValidTarget(W.Range))
            {
                Helper.CastManager.CastSkillShot(W, HitChance.VeryHigh, target, true);
            }
            if (SpellHelper.SpellIsReadyAndActive(E, HarassE) && target.IsValidTarget(E.Range))
            {
                Helper.CastManager.CastSkillShot(E, HitChance.VeryHigh, target, false);
                if (E.GetPrediction(target, false).Hitchance < HitChance.Medium)
                {
                    if (HarassReturnBack)
                    {
                        W.Cast(target);
                    }
                }
            }
            if ((target.HasBuff("leblanceroot") || !E.IsReady() || !HarassE) && HarassReturnBack)
            {
                W.Cast(target);
            }

        }
    }
}
