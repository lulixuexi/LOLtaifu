﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnsoulSharp.SDK.Prediction;
using xDreamms_LeBlanc.Helper;
using xDreamms_LeBlanc.Spells;

namespace xDreamms_LeBlanc.Modes
{
    public class JungleClearManager : SpellManager
    {
        public static void JungleClear()
        {
            var mobs = Helper.MinionManager.GetJungleMobs(Q.Range).OrderBy(x => x.MaxHealth);
            if (!mobs.Any()) return;
            if (SpellHelper.SpellIsReadyAndActive(Q, JungleClearQ))
            {
                Helper.CastManager.CastTargeted(Q, mobs.FirstOrDefault(), false);
            }
            if (SpellHelper.SpellIsReadyAndActive(W, JungleClearW) && !WReturn())
            {
                W.Cast(mobs.FirstOrDefault().Position);
            }
            if (SpellHelper.SpellIsReadyAndActive(R, JungleClearR) && !RReturn())
            {
                switch (R.Name)
                {
                    case "LeblancRQ":
                        GetRSpell().CastOnUnit(mobs.FirstOrDefault());
                        break;
                    case "LeblancRW":
                        var mobCircular = GetRSpell().GetCircularFarmLocation(mobs.ToList());
                        GetRSpell().Cast(mobCircular.Position);
                        break;
                    case "LeblancRE":
                        Helper.CastManager.CastSkillShot(GetRSpell(), HitChance.VeryHigh, mobs.FirstOrDefault(), true);
                        break;
                }
            }
            if (SpellHelper.SpellIsReadyAndActive(E, JungleClearE))
            {
                Helper.CastManager.CastSkillShot(E, HitChance.VeryHigh, mobs.FirstOrDefault(), false);
            }

        }
    }
}
