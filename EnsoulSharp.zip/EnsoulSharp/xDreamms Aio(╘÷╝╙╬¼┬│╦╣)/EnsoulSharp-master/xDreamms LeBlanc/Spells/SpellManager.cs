﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnsoulSharp;
using EnsoulSharp.SDK;
using EnsoulSharp.SDK.MenuUI;
using EnsoulSharp.SDK.Prediction;
using MenuManager = xDreamms_LeBlanc.Menu.MenuManager;

namespace xDreamms_LeBlanc.Spells
{
    public class SpellManager : MenuManager
    {
        public static Spell Q, W, W2, E, R;
        public static SpellSlot Ignite;


        public static void LoadSpells()
        {
            Q = new Spell(SpellSlot.Q, 700);
            W = new Spell(SpellSlot.W, 680);
            W2 = new Spell(SpellSlot.W);
            E = new Spell(SpellSlot.E, 950);
            R = new Spell(SpellSlot.R);
            Ignite = Player.GetSpellSlot("summonerdot");

            Q.SetTargetted(0.25f, float.MaxValue);
            W.SetSkillshot(0.25f, 80f, float.MaxValue, false, false, SkillshotType.Circle);
            E.SetSkillshot(0.25f, 55f, 1750, true, true, SkillshotType.Line);
        }
    }
}
