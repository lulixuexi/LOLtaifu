﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnsoulSharp;
using EnsoulSharp.SDK;
using xDreamms_LeBlanc.Modes;
using xDreamms_LeBlanc.Spells;
using System.Drawing;
namespace xDreamms_LeBlanc.Events
{
    public class EventManager : SpellManager
    {

        public static void LoadEvents()
        {
            Game.OnTick += GameOnOnTick;
            Drawing.OnDraw += DrawingOnOnDraw;
            Gapcloser.OnGapcloser += GapcloserOnOnGapcloser;
            GameObject.OnCreate += GameObjectOnOnCreate;
            GameObject.OnDelete += GameObjectOnOnDelete;
            Game.OnWndProc += GameOnOnWndProc;
        }

        private static void GameOnOnWndProc(WndEventArgs args)
        {
            if (args.Msg != 0x20a)
                return;
            ChangeComboWMode();
        }
        private static void ChangeComboWMode()
        {
            switch (ComboWMode)
            {
                case "Only target":
                    Helper.MenuHelper.SetMenuList(Config, "Combo", "ComboWMode", 1);
                    break;
                case "Closer to the enemy":
                    Helper.MenuHelper.SetMenuList(Config, "Combo", "ComboWMode", 0);
                    break;
            }
        }

        private static void GameObjectOnOnDelete(GameObject sender, EventArgs args)
        {
            if (sender.Position.Distance(Player.Position) < 1000)
            {
                if (sender.Name == "LeBlanc_Base_W_Return_indicator_death")
                {
                    WObject = null;
                }
                if (sender.Name == "LeBlanc_Base_RW_Return_indicator_death")
                {
                    RWObject = null;
                }
            }
        }

        private static void GameObjectOnOnCreate(GameObject sender, EventArgs args)
        {
            if (sender.Position.Distance(Player.Position) < 1000 )
            {
                if (sender.Name == "LeBlanc_Base_W_return_indicator")
                {
                    WObject = sender;
                }
                if (sender.Name == "LeBlanc_Base_RW_return_indicator")
                {
                    RWObject = sender;
                }
            }
        }

        private static void GapcloserOnOnGapcloser(AIHeroClient sender, Gapcloser.GapcloserArgs args)
        {
            if (!sender.IsEnemy) return;
            if (E.IsReady() && GapCloserE)
            {
                E.Cast(sender);
            }
        }

        private static void DrawingOnOnDraw(EventArgs args)
        {
            Helper.DrawingManager.DrawCircle(Player.Position, Q.Range, Color.Purple, DrawQ);
            Helper.DrawingManager.DrawCircle(Player.Position, W.Range, Color.Blue, DrawW);
            Helper.DrawingManager.DrawCircle(Player.Position, E.Range, Color.Red, DrawE);
            Helper.DrawingManager.DrawText(Player.Position, 0, 40, Color.White, "Active Mode: " + ComboMode, DrawComboMode);
            Helper.DrawingManager.DrawText(Player.Position, 0, 60, Color.Aqua, "W mode: " + ComboWMode, DrawComboWMode);
            if (WObject != null)
            {
                Helper.DrawingManager.DrawCircle(WObject.Position, 100, Color.Purple, DrawWPosition);
            }
            if (RWObject != null)
            {
                Helper.DrawingManager.DrawCircle(RWObject.Position, 100, Color.Purple, DrawRWPosition);
            }
            if (DrawDamage)
            {
                foreach (
                    var enemyVisible in
                    ObjectManager.Get<AIHeroClient>().Where(enemyVisible => enemyVisible.IsValidTarget()))
                {

                    if (GetComboDamage(enemyVisible) > enemyVisible.Health)
                    {
                        Drawing.DrawText(Drawing.WorldToScreen(enemyVisible.Position)[0] + 50,
                            Drawing.WorldToScreen(enemyVisible.Position)[1] - 40, Color.Red,
                            "Combo=Rekt");
                    }
                    else if (GetComboDamage(enemyVisible) + Player.GetAutoAttackDamage(enemyVisible) * 2 >
                             enemyVisible.Health)
                    {
                        Drawing.DrawText(Drawing.WorldToScreen(enemyVisible.Position)[0] + 50,
                            Drawing.WorldToScreen(enemyVisible.Position)[1] - 40, Color.Orange,
                            "Combo + 2 AA = Rekt");
                    }
                    else
                        Drawing.DrawText(Drawing.WorldToScreen(enemyVisible.Position)[0] + 50,
                            Drawing.WorldToScreen(enemyVisible.Position)[1] - 40, Color.White,
                            "Unkillable with combo + 2AA");
                }
            }
        }

        private static void GameOnOnTick(EventArgs args)
        {
            if (Orbwalker.ActiveMode == OrbwalkerMode.Combo)
            {
                ComboManager.Combo();
            }
            if (Orbwalker.ActiveMode == OrbwalkerMode.Harass)
            {
                HarassManager.Harass();
            }
            if (Orbwalker.ActiveMode == OrbwalkerMode.LaneClear)
            {
                LaneClearManager.LaneClear();
                JungleClearManager.JungleClear();
            }
            if (Orbwalker.ActiveMode == OrbwalkerMode.LastHit)
            {
                LastHitManager.LastHit();
            }
            if (ChangeComboMode)
            {
                ChangeMode();
            }
            if (FleeActive)
            {
                FleeManager.Flee();
            }
            KillStealManager.KillSteal();
        }
        private static void ChangeMode()
        {
            switch (ComboMode)
            {
                case "Q-R-W-E":
                    Helper.MenuHelper.SetMenuList(Config, "Combo", "ComboMode", 1);
                    break;
                case "W-R-Q-E":
                    Helper.MenuHelper.SetMenuList(Config, "Combo", "ComboMode", 2);
                    break;
                case "E-R-Q-W":
                    Helper.MenuHelper.SetMenuList(Config, "Combo", "ComboMode", 0);
                    break;
            }
        }
    }
}
